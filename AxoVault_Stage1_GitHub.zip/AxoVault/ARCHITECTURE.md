# AXO VAULT – Architecture
Single-module Android app. Kotlin + Jetpack Compose (Material 3), min SDK 26, target 35.
Layers: ui/ (Compose screens + ViewModels) -> data/ (Room, DataStore, repositories) -> security/ (Keystore, hashing, AES-GCM).
Packages: navigation/, ui/theme, ui/splash, ui/common, [Stage 2] security/, ui/onboarding, ui/lock,
[Stage 3] data/db, ui/notes, ui/folders, [Stage 4] vault/, [Stage 5] reminders/, backup/, [Stage 6] settings/.
Security plan: master password -> PBKDF2 hash (salted); data keys wrapped by Android Keystore (AES-256-GCM); vault notes/attachments encrypted per-item with AES-GCM.
No INTERNET permission. allowBackup=false.
