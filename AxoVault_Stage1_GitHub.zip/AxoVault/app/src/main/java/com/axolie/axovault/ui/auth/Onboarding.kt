package com.axolie.axovault.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolie.axovault.data.MainVM
import com.axolie.axovault.security.*
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.theme.Axo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val AutoLockOptions = listOf(15 to "15 seconds", 30 to "30 seconds", 60 to "1 minute", 300 to "5 minutes", 900 to "15 minutes", 0 to "Never")

@Composable
fun Onboarding(vm: MainVM, onDone: () -> Unit) {
    val prefs = vm.prefs
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(0) }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var a by remember { mutableStateOf("") }
    var autoLock by remember { mutableIntStateOf(60) }
    var lockBg by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val bioAvail = remember { biometricAvailable(ctx) }
    val titles = listOf("Welcome", "Master password", "Quick PIN", "Biometrics & auto-lock", "Recovery")

    fun next() {
        err = null
        when (step) {
            1 -> if (pw.length < 8) { err = "Use at least 8 characters"; return } else if (pw != pw2) { err = "Passwords do not match"; return }
            2 -> if (pin.length !in 4..8) { err = "PIN must be 4-8 digits"; return } else if (pin != pin2) { err = "PINs do not match"; return }
            4 -> {
                if ((q.isBlank()) != (a.isBlank())) { err = "Fill both question and answer, or leave both empty"; return }
                busy = true
                scope.launch {
                    val h = withContext(Dispatchers.Default) {
                        Triple(Crypto.hash(pw), Crypto.hash(pin), if (a.isNotBlank()) Crypto.hash(a.trim().lowercase()) else "")
                    }
                    withContext(Dispatchers.Default) { Crypto.dataKey() }
                    prefs.passHash = h.first; prefs.pinHash = h.second; prefs.pinLen = pin.length
                    if (a.isNotBlank()) { prefs.question = q.trim(); prefs.answerHash = h.third }
                    prefs.biometric = bio; prefs.autoLockSec = autoLock; prefs.lockOnBg = lockBg
                    prefs.configured = true
                    Session.unlock()
                    onDone()
                }
                return
            }
        }
        step++
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(24.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(5) { i -> Box(Modifier.height(4.dp).weight(1f).background(if (i <= step) Axo.Cyan else Axo.TextSecondary.copy(alpha = 0.3f))) }
        }
        Spacer(Modifier.height(24.dp))
        Text(titles[step], fontSize = 26.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        when (step) {
            0 -> {
                Text("AXO VAULT keeps your notes on this phone only. Nothing is uploaded and the app has no internet access. Let's set up your security in a few steps.")
            }
            1 -> {
                Text("This password unlocks the app. It is never stored - only a salted, slow hash of it.", fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                NeonField(pw, { pw = it }, "Master password (min 8)", password = true)
                Spacer(Modifier.height(10.dp))
                NeonField(pw2, { pw2 = it }, "Repeat password", password = true)
            }
            2 -> {
                Text("A 4-8 digit PIN for quick unlock.", fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                NeonField(pin, { pin = it.filter(Char::isDigit).take(8) }, "PIN", password = true, keyboardType = KeyboardType.NumberPassword)
                Spacer(Modifier.height(10.dp))
                NeonField(pin2, { pin2 = it.filter(Char::isDigit).take(8) }, "Repeat PIN", password = true, keyboardType = KeyboardType.NumberPassword)
            }
            3 -> {
                SettingRow("Fingerprint / face unlock", if (bioAvail) "Uses your phone's biometrics" else "Not available on this device") {
                    Switch(checked = bio, enabled = bioAvail, onCheckedChange = { on ->
                        if (!on) bio = false else {
                            val act = ctx.findActivity()
                            if (act != null) showBiometric(act, "Enable biometrics", { bio = true }, { err = it })
                        }
                    })
                }
                SettingRow("Lock when app goes to background") { Switch(checked = lockBg, onCheckedChange = { lockBg = it }) }
                SectionTitle("Auto-lock after inactivity")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AutoLockOptions.forEach { (s, l) -> NeonChip(l, autoLock == s, { autoLock = s }) }
                }
            }
            4 -> {
                Text("Optional: a security question lets you reset your password if you forget it. Your notes stay safe because they are encrypted with a key held by this phone's Android Keystore, not by your password.", fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Text("Limits: if you forget everything and set no question, or the app data / phone is wiped, the notes cannot be recovered. Make encrypted backups regularly (Settings > Backup).", fontSize = 14.sp, color = Axo.RgbPink)
                Spacer(Modifier.height(14.dp))
                NeonField(q, { q = it }, "Security question (optional)")
                Spacer(Modifier.height(10.dp))
                NeonField(a, { a = it }, "Answer")
            }
        }
        if (err != null) { Spacer(Modifier.height(10.dp)); Text(err!!, color = Axo.RgbPink) }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (step > 0) NeonButton("Back", { err = null; step-- }, Modifier.weight(1f), filled = false)
            NeonButton(if (step == 4) "Finish" else if (step == 0) "Start" else "Next", { next() }, Modifier.weight(1f), enabled = !busy)
        }
    }
}
