package com.axolie.axovault.data

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.axolie.axovault.AxoApp
import com.axolie.axovault.reminders.Reminders
import com.axolie.axovault.security.Crypto
import com.axolie.axovault.security.Session
import com.axolie.axovault.util.Markup
import com.axolie.axovault.util.Templates
import com.axolie.axovault.util.fmtDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainVM(app: Application) : AndroidViewModel(app) {
    private val ax = app as AxoApp
    val prefs = ax.prefs
    val auth = ax.auth
    private val dao = ax.db.dao()
    private val ctx: Application = app

    val notes: StateFlow<List<NoteEntity>> = dao.notes().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val folders: StateFlow<List<FolderEntity>> = dao.folders().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val attachments: StateFlow<List<AttachmentEntity>> = dao.attachments().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    var query by mutableStateOf("")
    var focusSearch by mutableStateOf(false)
    var tab by mutableIntStateOf(0)
    var pendingFolder by mutableLongStateOf(-1L)

    init {
        viewModelScope.launch(Dispatchers.IO) {
            dao.trashedBefore(System.currentTimeMillis() - 30L * 86_400_000L).forEach { deleteForeverSync(it) }
        }
    }

    // ---------- decrypted views ----------
    fun titleOf(e: NoteEntity): String =
        if (!e.encrypted) e.title
        else if (Session.vaultUnlocked) runCatching { Crypto.decryptText(e.title) }.getOrDefault("") else "Locked note"

    fun contentOf(e: NoteEntity): String =
        if (!e.encrypted) e.content
        else if (Session.vaultUnlocked) runCatching { Crypto.decryptText(e.content) }.getOrDefault("") else ""

    fun noteText(title: String, content: String, created: Long?): String = buildString {
        append(title.ifBlank { "Untitled" }).append("\n")
        if (created != null) append(fmtDate(created)).append("\n")
        append("\n").append(Markup.plain(content))
    }

    fun allNotesText(): String = notes.value.filter { !it.encrypted && it.trashedAt == null }
        .joinToString("\n\n--------------------\n\n") { noteText(it.title, it.content, it.createdAt) }

    // ---------- note operations ----------
    suspend fun getNote(id: Long): NoteEntity? = withContext(Dispatchers.IO) { dao.note(id) }

    suspend fun persist(e: NoteEntity, title: String, content: String): Long = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val row = if (e.encrypted) e.copy(title = Crypto.encryptText(title), content = Crypto.encryptText(content), modifiedAt = now)
        else e.copy(title = title, content = content, modifiedAt = now)
        val id = dao.upsert(row)
        Reminders.sync(ctx, row.copy(id = id))
        id
    }

    fun flush(e: NoteEntity, title: String, content: String) {
        if (e.id == 0L && title.isBlank() && content.isBlank()) return
        viewModelScope.launch { persist(e, title, content) }
    }

    fun update(e: NoteEntity) {
        viewModelScope.launch(Dispatchers.IO) { dao.upsert(e); Reminders.sync(ctx, e) }
    }

    fun toggleFav(e: NoteEntity) = update(e.copy(favorite = !e.favorite))
    fun togglePin(e: NoteEntity) = update(e.copy(pinned = !e.pinned))
    fun toggleArchive(e: NoteEntity) = update(e.copy(archived = !e.archived, pinned = false))
    fun trash(e: NoteEntity) = update(e.copy(trashedAt = System.currentTimeMillis(), pinned = false))
    fun restore(e: NoteEntity) = update(e.copy(trashedAt = null))

    private suspend fun deleteForeverSync(e: NoteEntity) {
        dao.attachmentsOf(e.id).forEach { File(it.path).delete(); dao.deleteAttachment(it.id) }
        dao.deleteNote(e.id)
        Reminders.cancel(ctx, e.id)
    }

    fun deleteForever(e: NoteEntity) { viewModelScope.launch(Dispatchers.IO) { deleteForeverSync(e) } }
    fun emptyTrash() {
        viewModelScope.launch(Dispatchers.IO) { notes.value.filter { it.trashedAt != null }.forEach { deleteForeverSync(it) } }
    }

    fun duplicate(e: NoteEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val title = titleOf(e) + " (copy)"
            val content = contentOf(e)
            val base = e.copy(id = 0, createdAt = now, modifiedAt = now, pinned = false, trashedAt = null, reminderAt = null, reminderDone = false)
            val row = if (e.encrypted) base.copy(title = Crypto.encryptText(title), content = Crypto.encryptText(content)) else base.copy(title = title, content = content)
            val newId = dao.upsert(row)
            dao.attachmentsOf(e.id).forEach { a ->
                val f = File(a.path)
                val nf = File(f.parentFile, UUID.randomUUID().toString() + ".bin")
                runCatching { f.copyTo(nf); dao.upsertAttachment(a.copy(id = 0, noteId = newId, path = nf.absolutePath)) }
            }
        }
    }

    fun quickNote(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val title = text.trim().lineSequence().first().take(30)
            dao.upsert(NoteEntity(title = title, content = text.trim(), tags = "quick", color = prefs.defaultColor))
        }
    }

    fun openJournal(onId: (Long) -> Unit) {
        viewModelScope.launch {
            val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val title = "Journal $day"
            val id = withContext(Dispatchers.IO) {
                notes.value.firstOrNull { !it.encrypted && it.trashedAt == null && it.title == title && "journal" in it.tagList() }?.id
                    ?: dao.upsert(NoteEntity(title = title, content = Templates.byKey("journal")!!.body, tags = "journal", color = prefs.defaultColor))
            }
            onId(id)
        }
    }

    // ---------- folders ----------
    fun saveFolder(f: FolderEntity) { viewModelScope.launch(Dispatchers.IO) { dao.upsertFolder(f) } }
    fun deleteFolder(f: FolderEntity) {
        viewModelScope.launch(Dispatchers.IO) { dao.clearFolder(f.id); dao.deleteFolder(f.id) }
    }

    // ---------- vault ----------
    suspend fun moveVault(e: NoteEntity, on: Boolean): NoteEntity = withContext(Dispatchers.IO) {
        val title = titleOf(e)
        val content = contentOf(e)
        dao.attachmentsOf(e.id).forEach { a ->
            if (a.encrypted != on) {
                val plain = readAttachment(a)
                File(a.path).writeBytes(if (on) Crypto.encryptBytes(plain) else plain)
                dao.upsertAttachment(a.copy(encrypted = on))
            }
        }
        val base = e.copy(encrypted = on, folderId = null, modifiedAt = System.currentTimeMillis())
        val row = if (on) base.copy(title = Crypto.encryptText(title), content = Crypto.encryptText(content)) else base.copy(title = title, content = content)
        dao.upsert(row)
        row
    }

    // ---------- attachments ----------
    suspend fun addAttachment(uri: Uri, noteId: Long, encrypted: Boolean): Boolean = withContext(Dispatchers.IO) {
        try {
            val cr = ctx.contentResolver
            var name = "file"
            cr.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i) ?: name
                }
            }
            val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: return@withContext false
            if (bytes.size > 25 * 1024 * 1024) return@withContext false
            val dir = File(ctx.filesDir, "att").apply { mkdirs() }
            val f = File(dir, UUID.randomUUID().toString() + ".bin")
            f.writeBytes(if (encrypted) Crypto.encryptBytes(bytes) else bytes)
            dao.upsertAttachment(AttachmentEntity(noteId = noteId, name = name, mime = cr.getType(uri) ?: "application/octet-stream", path = f.absolutePath, encrypted = encrypted))
            true
        } catch (e: Exception) { false }
    }

    suspend fun readAttachment(a: AttachmentEntity): ByteArray {
        val raw = File(a.path).readBytes()
        return if (a.encrypted) Crypto.decryptBytes(raw) else raw
    }

    fun deleteAttachment(a: AttachmentEntity) {
        viewModelScope.launch(Dispatchers.IO) { File(a.path).delete(); dao.deleteAttachment(a.id) }
    }

    fun storageBytes(): Long {
        val db = ctx.getDatabasePath("axo.db").length()
        val att = File(ctx.filesDir, "att").listFiles()?.sumOf { it.length() } ?: 0L
        return db + att
    }

    // ---------- backup ----------
    suspend fun exportBackup(pw: String, includeVault: Boolean): ByteArray = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("v", 1)
        val fa = JSONArray()
        folders.value.forEach { f ->
            if (f.isVault && !includeVault) return@forEach
            fa.put(JSONObject().put("id", f.id).put("name", f.name).put("color", f.color).put("icon", f.icon).put("vault", f.isVault))
        }
        val na = JSONArray()
        notes.value.forEach { e ->
            if (e.encrypted && (!includeVault || !Session.vaultUnlocked)) return@forEach
            na.put(
                JSONObject().put("title", titleOf(e)).put("content", contentOf(e)).put("color", e.color).put("tags", e.tags)
                    .put("folder", e.folderId ?: -1L).put("created", e.createdAt).put("modified", e.modifiedAt)
                    .put("pinned", e.pinned).put("fav", e.favorite).put("archived", e.archived)
                    .put("trashed", e.trashedAt ?: -1L).put("vault", e.encrypted)
                    .put("rem", e.reminderAt ?: -1L).put("remDone", e.reminderDone)
            )
        }
        root.put("folders", fa).put("notes", na)
        Crypto.encryptWithPassword(pw, root.toString().toByteArray(Charsets.UTF_8))
    }

    suspend fun importBackup(blob: ByteArray, pw: String, replace: Boolean): Int = withContext(Dispatchers.IO) {
        val json = JSONObject(String(Crypto.decryptWithPassword(pw, blob), Charsets.UTF_8))
        if (replace) {
            notes.value.forEach { deleteForeverSync(it) }
            folders.value.forEach { dao.deleteFolder(it.id) }
        }
        val existing = if (replace) emptyList() else folders.value
        val map = HashMap<Long, Long>()
        val fa = json.getJSONArray("folders")
        for (i in 0 until fa.length()) {
            val o = fa.getJSONObject(i)
            val name = o.getString("name")
            val vault = o.optBoolean("vault")
            val match = existing.firstOrNull { it.name == name && it.isVault == vault }
            map[o.getLong("id")] = match?.id ?: dao.upsertFolder(FolderEntity(name = name, color = o.optInt("color"), icon = o.optString("icon", "folder"), isVault = vault))
        }
        var count = 0
        val na = json.getJSONArray("notes")
        val now = System.currentTimeMillis()
        for (i in 0 until na.length()) {
            val o = na.getJSONObject(i)
            val vault = o.optBoolean("vault")
            val title = o.optString("title")
            val content = o.optString("content")
            val base = NoteEntity(
                title = title, content = content, color = o.optInt("color"), tags = o.optString("tags"),
                folderId = map[o.optLong("folder", -1L)], createdAt = o.optLong("created", now), modifiedAt = o.optLong("modified", now),
                pinned = o.optBoolean("pinned"), favorite = o.optBoolean("fav"), archived = o.optBoolean("archived"),
                trashedAt = o.optLong("trashed", -1L).takeIf { it > 0 }, encrypted = vault,
                reminderAt = o.optLong("rem", -1L).takeIf { it > 0 }, reminderDone = o.optBoolean("remDone")
            )
            val row = if (vault) base.copy(title = Crypto.encryptText(title), content = Crypto.encryptText(content)) else base
            val id = dao.upsert(row)
            Reminders.sync(ctx, row.copy(id = id))
            count++
        }
        count
    }
}
