package com.axolie.axovault.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.sp
import com.axolie.axovault.security.Prefs

data class Style(val palette: List<Color>, val accent: Color, val glow: Float, val cardAlpha: Float, val corner: Int)

val LocalStyle = staticCompositionLocalOf { Style(Axo.RgbPalette, Axo.Cyan, 0.6f, 0.1f, 20) }
val LocalPrefs = staticCompositionLocalOf<Prefs> { error("Prefs not provided") }

private fun mono(c: Color) = listOf(c, lerp(c, Color.White, 0.45f))

fun paletteFor(mode: String, custom: Int): List<Color> = when (mode) {
    "purple" -> mono(Axo.NeonPurple)
    "blue" -> mono(Axo.ElectricBlue)
    "red" -> mono(Color(0xFFFF2D2D))
    "green" -> mono(Axo.NeonGreen)
    "pink" -> mono(Axo.RgbPink)
    "cyan" -> mono(Axo.Cyan)
    "amoled" -> listOf(Color(0xFF3A3A44), Color(0xFF7A7A88))
    "custom" -> mono(Color(custom))
    else -> Axo.RgbPalette
}

private val AxoTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 32.sp, letterSpacing = 2.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 17.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 1.sp)
)

@Composable
fun AxoVaultTheme(prefs: Prefs, content: @Composable () -> Unit) {
    val dark = prefs.darkMode != "light"
    val palette = paletteFor(prefs.themeMode, prefs.customColor)
    val accent = if (prefs.themeMode == "rgb") Axo.Cyan else palette[0]
    val style = Style(palette, accent, prefs.glow, prefs.cardAlpha, prefs.corner)
    val scheme = if (dark) darkColorScheme(
        primary = accent, secondary = Axo.Cyan, tertiary = Axo.RgbPink,
        background = Axo.Amoled, surface = Axo.Surface,
        onPrimary = Color.Black, onBackground = Axo.TextPrimary, onSurface = Axo.TextPrimary
    ) else lightColorScheme(
        primary = accent, secondary = Color(0xFF0097A7), tertiary = Axo.RgbPink,
        background = Color(0xFFF4F4FA), surface = Color.White,
        onPrimary = Color.Black, onBackground = Color(0xFF14141C), onSurface = Color(0xFF14141C)
    )
    val phase = rememberPhaseState((6000 / prefs.animSpeed).toInt().coerceAtLeast(800), prefs.borderAnim)
    val d = LocalDensity.current
    CompositionLocalProvider(
        LocalStyle provides style,
        LocalPhase provides phase,
        LocalPrefs provides prefs,
        LocalDensity provides Density(d.density, d.fontScale * prefs.fontScale)
    ) {
        MaterialTheme(colorScheme = scheme, typography = AxoTypography, content = content)
    }
}
