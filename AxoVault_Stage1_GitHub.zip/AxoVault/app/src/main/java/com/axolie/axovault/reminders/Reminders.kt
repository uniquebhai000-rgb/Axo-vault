package com.axolie.axovault.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.axolie.axovault.AxoApp
import com.axolie.axovault.MainActivity
import com.axolie.axovault.data.NoteEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object Reminders {
    const val CH = "axo_reminders"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Note reminders", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun pi(ctx: Context, id: Long): PendingIntent = PendingIntent.getBroadcast(
        ctx, (id % Int.MAX_VALUE).toInt(),
        Intent(ctx, ReminderReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** Inexact-while-idle alarm: needs no special permission, may fire a few minutes late in Doze mode. */
    fun schedule(ctx: Context, id: Long, at: Long) {
        ctx.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, id))
    }

    fun cancel(ctx: Context, id: Long) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx, id))
    }

    fun sync(ctx: Context, e: NoteEntity) {
        val at = e.reminderAt
        if (at != null && !e.reminderDone && e.trashedAt == null && at > System.currentTimeMillis()) schedule(ctx, e.id, at)
        else cancel(ctx, e.id)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        if (id < 0) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val e = (ctx.applicationContext as AxoApp).db.dao().note(id)
                if (e != null && !e.reminderDone && e.trashedAt == null) {
                    // Private notes never show their content in notifications.
                    val text = if (e.encrypted) "Private note reminder" else e.title.ifBlank { "Untitled note" }
                    Reminders.ensureChannel(ctx)
                    val open = PendingIntent.getActivity(
                        ctx, 0, Intent(ctx, MainActivity::class.java),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    val n = NotificationCompat.Builder(ctx, Reminders.CH)
                        .setSmallIcon(android.R.drawable.ic_popup_reminder)
                        .setContentTitle("AXO VAULT reminder")
                        .setContentText(text)
                        .setContentIntent(open)
                        .setAutoCancel(true)
                        .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                        .build()
                    ctx.getSystemService(NotificationManager::class.java).notify((id % Int.MAX_VALUE).toInt(), n)
                }
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = (ctx.applicationContext as AxoApp).db.dao()
                val now = System.currentTimeMillis()
                dao.pendingReminders().forEach { e ->
                    val at = e.reminderAt ?: return@forEach
                    Reminders.schedule(ctx, e.id, maxOf(at, now + 5_000))
                }
            } finally {
                pending.finish()
            }
        }
    }
}
