package com.axolie.axovault.ui.common

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack

import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolie.axovault.ui.theme.*

val NoteColors = listOf(
    Color.Transparent, Color(0xFFB026FF), Color(0xFF2979FF), Color(0xFF00E5FF),
    Color(0xFF39FF14), Color(0xFFFF2DAA), Color(0xFFFFB300), Color(0xFFFF4D4D)
)

val FolderColors = NoteColors.drop(1)

val FolderIcons: Map<String, ImageVector> = mapOf(
    "folder" to Icons.Filled.Folder, "work" to Icons.Filled.Work, "home" to Icons.Filled.Home,
    "star" to Icons.Filled.Star, "book" to Icons.Filled.Book, "idea" to Icons.Filled.Lightbulb,
    "heart" to Icons.Filled.Favorite, "travel" to Icons.Filled.Flight, "money" to Icons.Filled.AccountBalanceWallet,
    "school" to Icons.Filled.School, "code" to Icons.Filled.Code, "lock" to Icons.Filled.Lock
)

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.Transparent,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val st = LocalStyle.current
    val shape = RoundedCornerShape(st.corner.dp)
    val fill = MaterialTheme.colorScheme.onSurface.copy(alpha = st.cardAlpha)
    Column(
        modifier
            .rgbBorder(shape, 1.5.dp)
            .clip(shape)
            .background(fill)
            .background(tint.copy(alpha = 0.14f))
            .then(if (onClick != null) Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick) else Modifier)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    filled: Boolean = true,
    enabled: Boolean = true
) {
    val st = LocalStyle.current
    val phase = LocalPhase.current
    val haptic = LocalHapticFeedback.current
    val prefs = LocalPrefs.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, label = "btn")
    val shape = RoundedCornerShape(minOf(st.corner, 28).dp)
    val base = modifier.scale(scale).let {
        if (filled) it.clip(shape).drawBehind { drawRect(Brush.horizontalGradient(rgbColorsAt(phase.value, st.palette))) }
        else it.rgbBorder(shape, 1.5.dp).clip(shape)
    }
    Row(
        base.clickable(interactionSource = src, indication = null, enabled = enabled) {
            if (prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            onClick()
        }.padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val c = (if (filled) Color.Black else MaterialTheme.colorScheme.onBackground).copy(alpha = if (enabled) 1f else 0.4f)
        if (icon != null) { Icon(icon, null, tint = c, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = c, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun NeonChip(text: String, selected: Boolean, onClick: () -> Unit, icon: ImageVector? = null) {
    val st = LocalStyle.current
    val shape = RoundedCornerShape(50)
    val m = if (selected) Modifier.background(st.accent, shape)
    else Modifier.border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f), shape)
    Row(
        Modifier.clip(shape).then(m).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, Modifier.size(16.dp), tint = if (selected) Color.Black else MaterialTheme.colorScheme.onBackground); Spacer(Modifier.width(6.dp)) }
        Text(text, fontSize = 13.sp, color = if (selected) Color.Black else MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun NeonField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    enabled: Boolean = true
) {
    val st = LocalStyle.current
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = singleLine, enabled = enabled,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(minOf(st.corner, 24).dp),
        visualTransformation = if (password && !show) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password && !show && keyboardType == KeyboardType.Text) KeyboardType.Password else keyboardType),
        trailingIcon = {
            if (password) IconButton(onClick = { show = !show }) {
                Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Show or hide")
            }
        },
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = st.accent, focusedLabelColor = st.accent, cursorColor = st.accent)
    )
}

@Composable
fun Screen(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } else Spacer(Modifier.width(16.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f), maxLines = 1)
            actions()
        }
        content()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), modifier = modifier.padding(top = 18.dp, bottom = 8.dp), fontSize = 12.sp, letterSpacing = 2.sp,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f), fontWeight = FontWeight.SemiBold)
}

@Composable
fun EmptyState(icon: ImageVector, title: String, text: String, modifier: Modifier = Modifier) {
    val st = LocalStyle.current
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(84.dp).rgbBorder(CircleShape, 2.dp), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = st.accent, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(text, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f), textAlign = TextAlign.Center)
    }
}

@Composable
fun SettingRow(title: String, subtitle: String? = null, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        }
        trailing()
    }
}

@Composable
fun PinPad(value: String, maxLen: Int, onChange: (String) -> Unit, enabled: Boolean = true, extra: @Composable () -> Unit = {}) {
    val st = LocalStyle.current
    val off = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(bottom = 20.dp)) {
            repeat(maxLen) { i -> Box(Modifier.size(14.dp).clip(CircleShape).background(if (i < value.length) st.accent else off)) }
        }
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("x", "0", "<")).forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                r.forEach { k ->
                    Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                        when (k) {
                            "x" -> extra()
                            "<" -> IconButton(onClick = { if (enabled && value.isNotEmpty()) onChange(value.dropLast(1)) }) {
                                Icon(Icons.Filled.Backspace, "Delete")
                            }
                            else -> Box(
                                Modifier.size(68.dp).rgbBorder(CircleShape, 1.dp).clip(CircleShape)
                                    .clickable { if (enabled && value.length < maxLen) onChange(value + k) },
                                contentAlignment = Alignment.Center
                            ) { Text(k, fontSize = 24.sp) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}
