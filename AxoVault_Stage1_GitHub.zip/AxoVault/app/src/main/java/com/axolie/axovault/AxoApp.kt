package com.axolie.axovault

import android.app.Application
import com.axolie.axovault.data.AppDb
import com.axolie.axovault.reminders.Reminders
import com.axolie.axovault.security.Auth
import com.axolie.axovault.security.Crypto
import com.axolie.axovault.security.Prefs

class AxoApp : Application() {
    lateinit var prefs: Prefs
    lateinit var db: AppDb
    lateinit var auth: Auth

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        Crypto.init(prefs)
        db = AppDb.get(this)
        auth = Auth(prefs)
        Reminders.ensureChannel(this)
    }
}
