package com.axolie.axovault.security

import android.content.Context
import android.content.ContextWrapper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object Session {
    var locked by mutableStateOf(true)
    var vaultUnlocked by mutableStateOf(false)
    @Volatile var lastTouch = System.currentTimeMillis()
    @Volatile var skipUntil = 0L

    fun touch() { lastTouch = System.currentTimeMillis() }
    fun unlock() { locked = false; touch() }
    fun lock() { locked = true; vaultUnlocked = false }
    fun unlockVault() { vaultUnlocked = true; touch() }
    /** Call before opening a file picker / share sheet so returning to the app does not trigger lock-on-background. */
    fun external() { skipUntil = System.currentTimeMillis() + 60_000 }
}

class Auth(private val p: Prefs) {
    fun remainingMs(): Long = maxOf(0L, p.lockedUntil - System.currentTimeMillis())
    fun fail() {
        val f = p.failCount + 1
        p.failCount = f
        if (f >= 5) {
            val d = minOf(30_000L shl minOf(f - 5, 7), 3_600_000L)
            p.lockedUntil = System.currentTimeMillis() + d
        }
    }
    fun ok() { p.failCount = 0; p.lockedUntil = 0L }
    fun checkPassword(s: String) = Crypto.verify(s, p.passHash)
    fun checkPin(s: String) = Crypto.verify(s, p.pinHash)
    fun checkAnswer(s: String) = Crypto.verify(s.trim().lowercase(), p.answerHash)
}

fun Context.findActivity(): FragmentActivity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is FragmentActivity) return c
        c = c.baseContext
    }
    return null
}

fun biometricAvailable(ctx: Context): Boolean =
    BiometricManager.from(ctx).canAuthenticate(BIOMETRIC_STRONG or BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

fun showBiometric(act: FragmentActivity, title: String, onOk: () -> Unit, onErr: (String) -> Unit) {
    val prompt = BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onErr(errString.toString()) }
    })
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setNegativeButtonText("Use PIN / password")
        .setAllowedAuthenticators(BIOMETRIC_STRONG or BIOMETRIC_WEAK)
        .build()
    prompt.authenticate(info)
}
