package com.axolie.axovault.util

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.StaticLayout
import android.text.TextPaint
import android.text.format.DateFormat
import android.widget.Toast
import com.axolie.axovault.security.Session
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun fmtDate(ts: Long): String = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ts))
fun fmtDay(ts: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ts))
fun wordCount(s: String): Int = s.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
fun safeName(s: String): String = s.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifBlank { "note" }.take(40)
fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

fun Context.writeUri(uri: Uri, bytes: ByteArray): Boolean = try {
    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
    true
} catch (e: Exception) { false }

fun pickDateTime(ctx: Context, initial: Long, onPicked: (Long) -> Unit) {
    val c = Calendar.getInstance().apply { timeInMillis = initial }
    DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, min ->
            val r = Calendar.getInstance().apply { set(y, m, d, h, min, 0); set(Calendar.MILLISECOND, 0) }
            onPicked(r.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), DateFormat.is24HourFormat(ctx)).show()
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
}

object Media {
    fun decode(bytes: ByteArray, max: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
    }
}

object Export {
    fun pdf(title: String, body: String): ByteArray {
        val doc = PdfDocument()
        val paint = TextPaint().apply { textSize = 12f; color = Color.BLACK; isAntiAlias = true }
        val text = title.ifBlank { "Untitled" } + "\n\n" + body
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, 495).setLineSpacing(2f, 1f).build()
        var line = 0
        var pageNo = 1
        while (line < layout.lineCount) {
            val top = layout.getLineTop(line)
            var end = line
            while (end < layout.lineCount && layout.getLineBottom(end) - top <= 760) end++
            if (end == line) end++
            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            val c = page.canvas
            c.translate(50f, 40f - top)
            c.clipRect(0f, top.toFloat(), 495f, layout.getLineBottom(end - 1).toFloat())
            layout.draw(c)
            doc.finishPage(page)
            line = end
            pageNo++
        }
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    fun share(ctx: Context, title: String, text: String) {
        Session.external()
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        ctx.startActivity(Intent.createChooser(i, "Share note"))
    }
}

object Templates {
    data class T(val key: String, val name: String, val title: String, val body: String)

    val all = listOf(
        T("blank", "Blank note", "", ""),
        T("meeting", "Meeting notes", "Meeting - ", "# Meeting\n\n**Date:** \n**Attendees:** \n\n## Agenda\n- \n\n## Decisions\n- \n\n## Action items\n- [ ] "),
        T("todo", "To-do list", "To-do", "# To-do\n\n- [ ] \n- [ ] \n- [ ] "),
        T("project", "Project plan", "Project - ", "# Goal\n\n## Milestones\n1. \n2. \n\n## Tasks\n- [ ] \n\n## Risks\n- "),
        T("shopping", "Shopping list", "Shopping", "# Shopping\n\n- [ ] \n- [ ] "),
        T("ideas", "Idea board", "Idea - ", "# Idea\n\n**Problem:** \n**Solution:** \n\n## Next steps\n- "),
        T("journal", "Daily journal", "Journal", "# Today\n\n**Mood:** \n\n## Highlights\n- \n\n## Gratitude\n- \n\n## Notes\n")
    )

    fun byKey(k: String): T? = all.firstOrNull { it.key == k }
}
