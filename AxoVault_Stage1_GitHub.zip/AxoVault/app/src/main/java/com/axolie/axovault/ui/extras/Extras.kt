package com.axolie.axovault.ui.extras

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.axolie.axovault.data.*
import com.axolie.axovault.security.*
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.main.NoteCard
import com.axolie.axovault.ui.main.NotesList
import com.axolie.axovault.ui.theme.*
import com.axolie.axovault.util.*
import com.axolie.axovault.navigation.editor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun TrashScreen(vm: MainVM, nav: NavHostController) {
    val notes by vm.notes.collectAsState()
    val list = notes.filter { it.trashedAt != null }.sortedByDescending { it.trashedAt }
    var confirm by remember { mutableStateOf(false) }
    Screen("Trash", { nav.popBackStack() }, actions = {
        if (list.isNotEmpty()) TextButton(onClick = { confirm = true }) { Text("Empty", color = Axo.RgbPink) }
    }) {
        if (list.isEmpty()) EmptyState(Icons.Filled.Delete, "Trash is empty", "Deleted notes stay here for 30 days.")
        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { e ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(vm.titleOf(e).ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text("Deleted ${fmtDate(e.trashedAt ?: 0L)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                    Row {
                        TextButton(onClick = { vm.restore(e) }) { Icon(Icons.Filled.Restore, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Restore") }
                        TextButton(onClick = { vm.deleteForever(e) }) { Text("Delete forever", color = Axo.RgbPink) }
                    }
                }
            }
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Empty trash?") },
        text = { Text("All ${list.size} notes will be permanently deleted. This cannot be undone.") },
        confirmButton = { TextButton(onClick = { vm.emptyTrash(); confirm = false }) { Text("Delete all", color = Axo.RgbPink) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } })
}

@Composable
fun ArchiveScreen(vm: MainVM, nav: NavHostController) {
    val notes by vm.notes.collectAsState()
    val list = notes.filter { it.archived && it.trashedAt == null && !it.encrypted }.sortedByDescending { it.modifiedAt }
    Screen("Archive", { nav.popBackStack() }) {
        if (list.isEmpty()) EmptyState(Icons.Filled.Archive, "Nothing archived", "Archive notes you want to keep but hide from the main list.")
        else NotesList(vm, list, false, nav, 24)
    }
}

@Composable
fun RemindersScreen(vm: MainVM, nav: NavHostController) {
    val ctx = LocalContext.current
    val notes by vm.notes.collectAsState()
    val list = notes.filter { it.reminderAt != null && it.trashedAt == null }.sortedBy { it.reminderAt }
    Screen("Reminders", { nav.popBackStack() }) {
        if (list.isEmpty()) EmptyState(Icons.Filled.Alarm, "No reminders", "Open a note, tap the menu and choose Add reminder.")
        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { e ->
                val at = e.reminderAt ?: 0L
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.editor(e.id) }) {
                    Text(vm.titleOf(e).ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(fmtDate(at) + if (e.reminderDone) "  (completed)" else "", fontSize = 13.sp, color = if (e.reminderDone) Axo.NeonGreen else Axo.Cyan)
                    Row {
                        TextButton(onClick = { pickDateTime(ctx, maxOf(at, System.currentTimeMillis() + 60_000)) { t -> if (t > System.currentTimeMillis()) vm.update(e.copy(reminderAt = t, reminderDone = false)) else toast(ctx, "Pick a future time") } }) { Text("Edit") }
                        TextButton(onClick = { vm.update(e.copy(reminderDone = !e.reminderDone)) }) { Text(if (e.reminderDone) "Mark active" else "Mark done") }
                        TextButton(onClick = { vm.update(e.copy(reminderAt = null, reminderDone = false)) }) { Text("Delete", color = Axo.RgbPink) }
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarScreen(vm: MainVM, nav: NavHostController) {
    val notes by vm.notes.collectAsState()
    var offset by remember { mutableIntStateOf(0) }
    var selDay by remember { mutableStateOf<String?>(null) }
    val cal = remember(offset) { Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); add(Calendar.MONTH, offset) } }
    val firstDow = cal.get(Calendar.DAY_OF_WEEK) - 1
    val daysIn = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val live = notes.filter { it.trashedAt == null }
    val byDay = remember(live) {
        val m = HashMap<String, MutableList<NoteEntity>>()
        live.forEach { n ->
            m.getOrPut(fmtDay(n.createdAt)) { mutableListOf() }.add(n)
            n.reminderAt?.let { m.getOrPut(fmtDay(it)) { mutableListOf() }.let { l -> if (n !in l) l.add(n) } }
        }
        m
    }
    fun key(d: Int): String { val c = cal.clone() as Calendar; c.set(Calendar.DAY_OF_MONTH, d); return fmtDay(c.timeInMillis) }
    val today = fmtDay(System.currentTimeMillis())
    Screen("Calendar", { nav.popBackStack() }) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { offset--; selDay = null }) { Text("‹", fontSize = 28.sp) }
                Text(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(cal.timeInMillis)), Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { offset++; selDay = null }) { Text("›", fontSize = 28.sp) }
            }
            Row { listOf("S", "M", "T", "W", "T", "F", "S").forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp, color = Axo.TextSecondary) } }
            for (w in 0 until 6) {
                Row {
                    for (dw in 0 until 7) {
                        val d = w * 7 + dw - firstDow + 1
                        Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp), contentAlignment = Alignment.Center) {
                            if (d in 1..daysIn) {
                                val k = key(d)
                                val has = byDay[k]?.size ?: 0
                                Column(
                                    Modifier.fillMaxSize().clip(CircleShape)
                                        .background(if (selDay == k) Axo.Cyan.copy(alpha = 0.35f) else if (k == today) Axo.NeonPurple.copy(alpha = 0.3f) else Color.Transparent)
                                        .clickable { selDay = k },
                                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                                ) {
                                    Text("$d", fontSize = 14.sp)
                                    if (has > 0) Box(Modifier.size(5.dp).clip(CircleShape).background(Axo.RgbPink))
                                }
                            }
                        }
                    }
                }
            }
            val sel = selDay?.let { byDay[it] } ?: emptyList()
            if (selDay != null) {
                SectionTitle("Notes on this day")
                if (sel.isEmpty()) Text("No notes or reminders", color = Axo.TextSecondary)
                sel.forEach { n -> NoteCard(vm, n, { nav.editor(n.id) }, Modifier.padding(bottom = 10.dp)) }
            }
        }
    }
}

@Composable
fun StatsScreen(vm: MainVM, nav: NavHostController) {
    val notes by vm.notes.collectAsState()
    val folders by vm.folders.collectAsState()
    val live = notes.filter { it.trashedAt == null }
    val words = live.filter { !it.encrypted }.sumOf { wordCount(Markup.plain(it.content)) }
    val tags = live.flatMap { it.tagList() }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(6)
    val months = remember(live) {
        (5 downTo 0).map { back ->
            val c = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); add(Calendar.MONTH, -back) }
            val label = SimpleDateFormat("MMM", Locale.getDefault()).format(Date(c.timeInMillis))
            val y = c.get(Calendar.YEAR); val m = c.get(Calendar.MONTH)
            label to live.count { n -> val x = Calendar.getInstance().apply { timeInMillis = n.createdAt }; x.get(Calendar.YEAR) == y && x.get(Calendar.MONTH) == m }
        }
    }
    val maxV = (months.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
    Screen("Statistics", { nav.popBackStack() }) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassCard(Modifier.weight(1f)) { Text("${live.size}", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Notes", fontSize = 12.sp) }
                GlassCard(Modifier.weight(1f)) { Text("$words", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Words (public notes)", fontSize = 12.sp) }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassCard(Modifier.weight(1f)) { Text("${live.count { it.encrypted }}", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Private", fontSize = 12.sp) }
                GlassCard(Modifier.weight(1f)) { Text("${live.count { it.favorite }}", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Favourites", fontSize = 12.sp) }
                GlassCard(Modifier.weight(1f)) { Text("${live.count { it.archived }}", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Archived", fontSize = 12.sp) }
            }
            SectionTitle("Notes created, last 6 months")
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().height(140.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                    months.forEach { (l, v) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Text("$v", fontSize = 11.sp)
                            Box(Modifier.width(26.dp).height((100f * v / maxV).dp.coerceAtLeast(3.dp)).clip(RoundedCornerShape(6.dp)).background(Axo.Cyan))
                            Text(l, fontSize = 11.sp, color = Axo.TextSecondary)
                        }
                    }
                }
            }
            SectionTitle("Top tags")
            if (tags.isEmpty()) Text("No tags yet", color = Axo.TextSecondary)
            tags.forEach { Text("#${it.key}  ·  ${it.value}", Modifier.padding(vertical = 3.dp)) }
            SectionTitle("Folders")
            folders.filter { !it.isVault }.forEach { f -> Text("${f.name}  ·  ${live.count { it.folderId == f.id && !it.encrypted }} notes", Modifier.padding(vertical = 3.dp)) }
        }
    }
}

@Composable
fun BackupScreen(vm: MainVM, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var includeVault by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pendingBytes by remember { mutableStateOf<ByteArray?>(null) }
    var importBlob by remember { mutableStateOf<ByteArray?>(null) }
    var importPw by remember { mutableStateOf("") }
    var importErr by remember { mutableStateOf<String?>(null) }
    var replace by remember { mutableStateOf(false) }
    var confirmReplace by remember { mutableStateOf(false) }
    val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    val backupSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val b = pendingBytes
        msg = if (uri != null && b != null) { if (ctx.writeUri(uri, b)) "Encrypted backup saved. Keep the password safe - it cannot be recovered." else "Could not write the file." } else "Cancelled."
        pendingBytes = null
    }
    val txtSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val b = pendingBytes
        msg = if (uri != null && b != null) { if (ctx.writeUri(uri, b)) "Exported." else "Could not write the file." } else "Cancelled."
        pendingBytes = null
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bytes = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull() }
            if (bytes == null) msg = "Could not read that file." else { importBlob = bytes; importPw = ""; importErr = null; replace = false }
        }
    }

    fun runImport() {
        val blob = importBlob ?: return
        busy = true
        scope.launch {
            try {
                val n = vm.importBackup(blob, importPw, replace)
                msg = "Restored $n notes."; importBlob = null
            } catch (e: Exception) { importErr = "Wrong password or damaged backup file." }
            busy = false
        }
    }

    Screen("Backup & restore", { nav.popBackStack() }) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            if (msg != null) { GlassCard(Modifier.fillMaxWidth()) { Text(msg!!) }; Spacer(Modifier.height(10.dp)) }
            SectionTitle("Create encrypted backup")
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Backups are encrypted with AES-256-GCM using a key derived from the password you type. Attachments (images/files) are not included in backups.", fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                NeonField(pw, { pw = it }, "Backup password (min 8)", password = true)
                Spacer(Modifier.height(8.dp))
                NeonField(pw2, { pw2 = it }, "Repeat password", password = true)
                SettingRow("Include private vault notes", if (Session.vaultUnlocked) "Stored inside the encrypted backup" else "Unlock the vault first to enable") {
                    Switch(checked = includeVault, enabled = Session.vaultUnlocked, onCheckedChange = { includeVault = it })
                }
                NeonButton(if (busy) "Working…" else "Create backup", {
                    if (pw.length < 8 || pw != pw2) msg = "Password must match and be at least 8 characters."
                    else { busy = true; scope.launch { pendingBytes = vm.exportBackup(pw, includeVault && Session.vaultUnlocked); busy = false; Session.external(); backupSaver.launch("axo-vault-$stamp.axobak") } }
                }, Modifier.fillMaxWidth(), icon = Icons.Filled.Backup, enabled = !busy)
            }
            SectionTitle("Restore")
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Choose an .axobak file made by AXO VAULT. You can merge it with your current notes or replace everything.", fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                NeonButton("Choose backup file", { Session.external(); opener.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), icon = Icons.Filled.Restore, filled = false)
            }
            SectionTitle("Export notes as text")
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Exports all non-private notes into one plain TXT file. Private vault notes are never included here. To export a single note as TXT or PDF, open it and use the menu.", fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                NeonButton("Export all as TXT", { pendingBytes = vm.allNotesText().toByteArray(); Session.external(); txtSaver.launch("axo-notes-$stamp.txt") }, Modifier.fillMaxWidth(), icon = Icons.Filled.Download, filled = false)
            }
        }
    }

    if (importBlob != null) AlertDialog(
        onDismissRequest = { importBlob = null }, title = { Text("Restore backup") },
        text = {
            Column {
                NeonField(importPw, { importPw = it }, "Backup password", password = true)
                SettingRow("Replace all current data") { Switch(checked = replace, onCheckedChange = { replace = it }) }
                Text(if (replace) "All current notes and folders will be deleted first." else "Backup notes are added next to your current notes.", fontSize = 12.sp, color = if (replace) Axo.RgbPink else Axo.TextSecondary)
                if (importErr != null) Text(importErr!!, color = Axo.RgbPink)
            }
        },
        confirmButton = { TextButton(enabled = importPw.isNotEmpty() && !busy, onClick = { if (replace) confirmReplace = true else runImport() }) { Text("Restore") } },
        dismissButton = { TextButton(onClick = { importBlob = null }) { Text("Cancel") } }
    )
    if (confirmReplace) AlertDialog(onDismissRequest = { confirmReplace = false }, title = { Text("Overwrite existing data?") },
        text = { Text("This permanently deletes every note, folder and attachment currently in the app, then loads the backup. This cannot be undone.") },
        confirmButton = { TextButton(onClick = { confirmReplace = false; runImport() }) { Text("Overwrite", color = Axo.RgbPink) } },
        dismissButton = { TextButton(onClick = { confirmReplace = false }) { Text("Cancel") } })
}

@Composable
fun ThemeScreen(vm: MainVM, nav: NavHostController) {
    val p = vm.prefs
    val presets = listOf("rgb" to "Full RGB Neon", "purple" to "Purple Neon", "blue" to "Blue Neon", "red" to "Red Neon", "green" to "Green Neon", "pink" to "Pink Neon", "cyan" to "Cyan Neon", "amoled" to "AMOLED Black", "custom" to "Custom")
    var r by remember { mutableFloatStateOf(((p.customColor shr 16) and 0xFF) / 255f) }
    var g by remember { mutableFloatStateOf(((p.customColor shr 8) and 0xFF) / 255f) }
    var b by remember { mutableFloatStateOf((p.customColor and 0xFF) / 255f) }
    fun applyCustom() { p.customColor = Color(r, g, b).toArgb(); p.themeMode = "custom" }
    Screen("Customize", { nav.popBackStack() }) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Live preview", style = MaterialTheme.typography.titleMedium)
                Text("Cards, borders and glow follow your choices instantly.", fontSize = 13.sp)
            }
            SectionTitle("Theme")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { (k, l) -> NeonChip(l, p.themeMode == k, { p.themeMode = k }) }
            }
            if (p.themeMode == "custom") {
                SectionTitle("Custom accent")
                Box(Modifier.fillMaxWidth().height(28.dp).clip(RoundedCornerShape(10.dp)).background(Color(r, g, b)))
                Text("Red"); Slider(r, { r = it; applyCustom() })
                Text("Green"); Slider(g, { g = it; applyCustom() })
                Text("Blue"); Slider(b, { b = it; applyCustom() })
            }
            SectionTitle("Mode")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonChip("Dark", p.darkMode == "dark", { p.darkMode = "dark" })
                NeonChip("Light", p.darkMode == "light", { p.darkMode = "light" })
            }
            SectionTitle("Effects")
            GlassCard(Modifier.fillMaxWidth()) {
                SettingRow("Animated RGB borders", "Turn off to save battery") { Switch(checked = p.borderAnim, onCheckedChange = { p.borderAnim = it }) }
                SettingRow("Haptic feedback") { Switch(checked = p.haptics, onCheckedChange = { p.haptics = it }) }
                Text("Neon glow intensity"); Slider(p.glow, { p.glow = it })
                Text("Animation speed"); Slider(p.animSpeed, { p.animSpeed = it }, valueRange = 0.3f..3f)
                Text("Card transparency"); Slider(p.cardAlpha, { p.cardAlpha = it }, valueRange = 0.03f..0.4f)
                Text("Corner roundness (${p.corner} dp)"); Slider(p.corner.toFloat(), { p.corner = it.toInt() }, valueRange = 4f..32f)
                Text("Font size (${(p.fontScale * 100).toInt()}%)"); Slider(p.fontScale, { p.fontScale = it }, valueRange = 0.8f..1.4f)
            }
            Spacer(Modifier.height(12.dp))
            NeonButton("Reset to default (Full RGB Neon)", {
                p.themeMode = "rgb"; p.borderAnim = true; p.glow = 0.6f; p.animSpeed = 1f; p.cardAlpha = 0.10f; p.corner = 20; p.fontScale = 1f; p.darkMode = "dark"
            }, Modifier.fillMaxWidth(), filled = false)
        }
    }
}
