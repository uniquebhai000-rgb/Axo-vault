package com.axolie.axovault.ui.theme

import androidx.compose.ui.graphics.Color

object Axo {
    val Amoled = Color(0xFF000000)
    val Surface = Color(0xFF0B0B12)
    val NeonPurple = Color(0xFFB026FF)
    val ElectricBlue = Color(0xFF2979FF)
    val RgbPink = Color(0xFFFF2DAA)
    val NeonGreen = Color(0xFF39FF14)
    val Cyan = Color(0xFF00E5FF)
    val TextPrimary = Color(0xFFF2F2FA)
    val TextSecondary = Color(0xFF9A9AB0)

    /** Order matters: used for the animated RGB border cycle. */
    val RgbPalette = listOf(NeonPurple, ElectricBlue, Cyan, NeonGreen, RgbPink)
}
