package com.axolie.axovault

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.fragment.app.FragmentActivity
import com.axolie.axovault.navigation.AppNavHost
import com.axolie.axovault.security.Session
import com.axolie.axovault.ui.theme.AxoVaultTheme
import kotlinx.coroutines.delay

class MainActivity : FragmentActivity() {
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = (application as AxoApp).prefs
        setContent {
            AxoVaultTheme(prefs) {
                LaunchedEffect(prefs.secureWindow) {
                    // Hides content in screenshots and in the recent-apps preview.
                    if (prefs.secureWindow) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                LaunchedEffect(Unit) {
                    while (true) {
                        delay(2000)
                        if (prefs.configured && !Session.locked) {
                            val idle = System.currentTimeMillis() - Session.lastTouch
                            if (Session.vaultUnlocked && idle > prefs.vaultLockSec * 1000L) Session.vaultUnlocked = false
                            val al = prefs.autoLockSec
                            if (al > 0 && idle > al * 1000L) Session.lock()
                        }
                    }
                }
                AppNavHost()
            }
        }
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        Session.touch()
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        val prefs = (application as AxoApp).prefs
        if (prefs.configured && !Session.locked) {
            val now = System.currentTimeMillis()
            if (now < Session.skipUntil) {
                Session.skipUntil = 0L
            } else {
                val away = now - stoppedAt
                if (prefs.lockOnBg || (prefs.autoLockSec > 0 && away > prefs.autoLockSec * 1000L)) Session.lock()
            }
        }
    }
}
