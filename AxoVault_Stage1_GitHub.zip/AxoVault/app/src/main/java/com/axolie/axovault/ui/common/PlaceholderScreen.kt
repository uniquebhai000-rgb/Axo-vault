package com.axolie.axovault.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.axolie.axovault.ui.theme.Axo

/** Temporary screen so navigation can be tested. Replaced in later stages. */
@Composable
fun PlaceholderScreen(title: String, note: String) {
    Column(
        Modifier.fillMaxSize().background(Axo.Amoled).systemBarsPadding().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = Axo.Cyan)
        Spacer(Modifier.height(12.dp))
        Text(note, style = MaterialTheme.typography.bodyMedium, color = Axo.TextSecondary, textAlign = TextAlign.Center)
    }
}
