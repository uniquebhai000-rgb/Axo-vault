package com.axolie.axovault.util

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolie.axovault.ui.theme.Axo

/**
 * The editor stores notes as light markup text:
 * **bold** *italic* __underline__ ~~strike~~ ==highlight== {c:#RRGGBB|colour} {s:24|size} [text](url)
 * Line prefixes: "# " headings, "- " bullets, "1. " numbers, "- [ ] " checklist, ">c " centre, ">r " right.
 */
object Markup {
    val align = Regex("^>([lcr]) ")
    val block = Regex("^(#{1,3} |- \\[[ x]\\] |- |\\d+\\. )")
    private val inl = Regex("""\*\*(.+?)\*\*|__(.+?)__|~~(.+?)~~|==(.+?)==|\*(.+?)\*|\{c:#([0-9A-Fa-f]{6})\|(.+?)\}|\{s:(\d{1,2})\|(.+?)\}|\[(.+?)\]\((.+?)\)""")

    fun plain(t: String): String = t.lines().joinToString("\n") { raw ->
        var l = raw.replace(align, "")
        l = l.replace(block, "")
        l.replace(Regex("\\{c:#[0-9A-Fa-f]{6}\\|(.*?)\\}"), "\$1")
            .replace(Regex("\\{s:\\d+\\|(.*?)\\}"), "\$1")
            .replace(Regex("\\[(.*?)\\]\\((.*?)\\)"), "\$1")
            .replace(Regex("\\*\\*|__|~~|==|\\*"), "")
    }

    fun appendInline(b: AnnotatedString.Builder, t: String) {
        var i = 0
        for (m in inl.findAll(t)) {
            b.append(t.substring(i, m.range.first))
            val g = m.groupValues
            when {
                g[1].isNotEmpty() -> b.withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { appendInline(this, g[1]) }
                g[2].isNotEmpty() -> b.withStyle(SpanStyle(textDecoration = TextDecoration.Underline)) { appendInline(this, g[2]) }
                g[3].isNotEmpty() -> b.withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { appendInline(this, g[3]) }
                g[4].isNotEmpty() -> b.withStyle(SpanStyle(background = Color(0x66FFEB3B))) { appendInline(this, g[4]) }
                g[5].isNotEmpty() -> b.withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { appendInline(this, g[5]) }
                g[6].isNotEmpty() -> b.withStyle(SpanStyle(color = Color(android.graphics.Color.parseColor("#" + g[6])))) { appendInline(this, g[7]) }
                g[8].isNotEmpty() -> b.withStyle(SpanStyle(fontSize = g[8].toInt().sp)) { appendInline(this, g[9]) }
                g[10].isNotEmpty() -> {
                    val url = if (g[11].contains("://")) g[11] else "https://" + g[11]
                    b.withLink(LinkAnnotation.Url(url, TextLinkStyles(SpanStyle(color = Axo.Cyan, textDecoration = TextDecoration.Underline)))) { append(g[10]) }
                }
            }
            i = m.range.last + 1
        }
        b.append(t.substring(i))
    }

    // ---------- editing helpers ----------
    fun wrap(v: TextFieldValue, l: String, r: String = l): TextFieldValue {
        val s = v.selection.min
        val e = v.selection.max
        val t = v.text.substring(0, s) + l + v.text.substring(s, e) + r + v.text.substring(e)
        return v.copy(text = t, selection = if (s == e) TextRange(s + l.length) else TextRange(s + l.length, e + l.length))
    }

    fun insert(v: TextFieldValue, s: String): TextFieldValue {
        val a = v.selection.min
        val b = v.selection.max
        return v.copy(text = v.text.substring(0, a) + s + v.text.substring(b), selection = TextRange(a + s.length))
    }

    private fun editLine(v: TextFieldValue, fn: (String) -> String): TextFieldValue {
        val t = v.text
        val s = v.selection.min.coerceIn(0, t.length)
        val start = if (s == 0) 0 else t.lastIndexOf('\n', s - 1) + 1
        var end = t.indexOf('\n', s)
        if (end < 0) end = t.length
        val line = t.substring(start, end)
        val nl = fn(line)
        val nt = t.substring(0, start) + nl + t.substring(end)
        return v.copy(text = nt, selection = TextRange((v.selection.max + nl.length - line.length).coerceIn(0, nt.length)))
    }

    fun setBlock(v: TextFieldValue, prefix: String) = editLine(v) { l ->
        val a = align.find(l)?.value ?: ""
        val r = l.removePrefix(a)
        val b = block.find(r)?.value ?: ""
        a + (if (b == prefix) "" else prefix) + r.removePrefix(b)
    }

    fun cycleHeading(v: TextFieldValue) = editLine(v) { l ->
        val a = align.find(l)?.value ?: ""
        val r = l.removePrefix(a)
        val b = block.find(r)?.value ?: ""
        val next = when (b) { "# " -> "## "; "## " -> "### "; "### " -> ""; else -> "# " }
        a + next + r.removePrefix(b)
    }

    fun setAlign(v: TextFieldValue, tag: String) = editLine(v) { l ->
        val a = align.find(l)?.value ?: ""
        (if (tag == "l") "" else ">$tag ") + l.removePrefix(a)
    }

    fun autoContinue(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
        if (new.text.length != old.text.length + 1) return new
        val c = new.selection.start
        if (c < 1 || new.text[c - 1] != '\n') return new
        val ls = if (c < 2) 0 else new.text.lastIndexOf('\n', c - 2) + 1
        val prev = new.text.substring(ls, c - 1)
        val a = align.find(prev)?.value ?: ""
        val r = prev.removePrefix(a)
        val b = block.find(r)?.value ?: return new
        if (b.startsWith("#")) return new
        if (r.removePrefix(b).isEmpty()) {
            return new.copy(text = new.text.substring(0, ls) + new.text.substring(c), selection = TextRange(ls))
        }
        val nb = when {
            b.startsWith("- [") -> "- [ ] "
            b[0].isDigit() -> ((b.takeWhile { it.isDigit() }.toIntOrNull() ?: 0) + 1).toString() + ". "
            else -> b
        }
        val ins = a + nb
        return new.copy(text = new.text.substring(0, c) + ins + new.text.substring(c), selection = TextRange(c + ins.length))
    }

    fun toggleCheck(t: String, idx: Int): String {
        val ls = t.lines().toMutableList()
        if (idx !in ls.indices) return t
        val l = ls[idx]
        ls[idx] = if (l.contains("- [ ] ")) l.replaceFirst("- [ ] ", "- [x] ") else l.replaceFirst("- [x] ", "- [ ] ")
        return ls.joinToString("\n")
    }
}

@Composable
fun MarkupView(text: String, onToggle: (Int) -> Unit) {
    val col = MaterialTheme.colorScheme.onBackground
    Column(Modifier.fillMaxWidth()) {
        text.lines().forEachIndexed { idx, raw ->
            val am = Markup.align.find(raw)
            val a = am?.groupValues?.get(1) ?: "l"
            var line = raw.removePrefix(am?.value ?: "")
            val b = Markup.block.find(line)?.value ?: ""
            line = line.removePrefix(b)
            val ta = when (a) { "c" -> TextAlign.Center; "r" -> TextAlign.End; else -> TextAlign.Start }
            val size = when (b) { "# " -> 26.sp; "## " -> 22.sp; "### " -> 18.sp; else -> 16.sp }
            val weight = if (b.startsWith("#")) FontWeight.Bold else FontWeight.Normal
            val body = buildAnnotatedString { Markup.appendInline(this, line) }
            when {
                raw.isEmpty() -> Spacer(Modifier.height(10.dp))
                b.startsWith("- [") -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = b.contains("x"), onCheckedChange = { onToggle(idx) })
                    Text(body, color = col, fontSize = size, modifier = Modifier.weight(1f))
                }
                b == "- " -> Row(Modifier.padding(start = 8.dp, top = 2.dp)) {
                    Text("•  ", color = col, fontSize = size)
                    Text(body, color = col, fontSize = size, modifier = Modifier.weight(1f))
                }
                b.isNotEmpty() && b[0].isDigit() -> Row(Modifier.padding(start = 8.dp, top = 2.dp)) {
                    Text(b, color = col, fontSize = size)
                    Text(body, color = col, fontSize = size, modifier = Modifier.weight(1f))
                }
                else -> Text(body, color = col, fontSize = size, fontWeight = weight, textAlign = ta, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp))
            }
        }
    }
}
