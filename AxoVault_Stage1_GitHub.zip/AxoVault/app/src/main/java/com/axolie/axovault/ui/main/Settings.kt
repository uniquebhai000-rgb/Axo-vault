package com.axolie.axovault.ui.main

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.axolie.axovault.data.*
import com.axolie.axovault.security.*
import com.axolie.axovault.ui.auth.*
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.theme.*
import com.axolie.axovault.util.*
import com.axolie.axovault.navigation.editor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun <T> ChoiceDialog(title: String, options: List<Pair<T, String>>, selected: T, onPick: (T) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column {
                options.forEach { (v, l) ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(v); onDismiss() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = v == selected, onClick = { onPick(v); onDismiss() })
                        Spacer(Modifier.width(8.dp)); Text(l)
                    }
                }
            }
        }, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

@Composable
fun SecretDialog(vm: MainVM, mode: String, onDismiss: () -> Unit) {
    val prefs = vm.prefs
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var cur by remember { mutableStateOf("") }
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val title = when (mode) { "password" -> "Change master password"; "pin" -> "Change PIN"; else -> "Recovery question" }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                NeonField(cur, { cur = it }, "Current master password", password = true)
                Spacer(Modifier.height(8.dp))
                when (mode) {
                    "password" -> { NeonField(a, { a = it }, "New password (min 8)", password = true); Spacer(Modifier.height(8.dp)); NeonField(b, { b = it }, "Repeat new password", password = true) }
                    "pin" -> { NeonField(a, { a = it.filter(Char::isDigit).take(8) }, "New PIN (4-8 digits)", password = true, keyboardType = KeyboardType.NumberPassword); Spacer(Modifier.height(8.dp)); NeonField(b, { b = it.filter(Char::isDigit).take(8) }, "Repeat PIN", password = true, keyboardType = KeyboardType.NumberPassword) }
                    else -> { NeonField(a, { a = it }, "Security question"); Spacer(Modifier.height(8.dp)); NeonField(b, { b = it }, "Answer") }
                }
                if (prefs.question.isNotEmpty() && mode == "recovery") Text("Leave both empty to remove the recovery question.", fontSize = 12.sp)
                if (err != null) Text(err!!, color = Axo.RgbPink)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    mode == "password" && (a.length < 8 || a != b) -> err = "Password must match and be 8+ characters"
                    mode == "pin" && (a.length < 4 || a != b) -> err = "PIN must match and be 4-8 digits"
                    mode == "recovery" && (a.isBlank() != b.isBlank()) -> err = "Fill both fields or leave both empty"
                    else -> scope.launch {
                        val ok = withContext(Dispatchers.Default) { vm.auth.checkPassword(cur) }
                        if (!ok) { vm.auth.fail(); err = "Current password is wrong"; return@launch }
                        withContext(Dispatchers.Default) {
                            when (mode) {
                                "password" -> prefs.passHash = Crypto.hash(a)
                                "pin" -> { prefs.pinHash = Crypto.hash(a); prefs.pinLen = a.length }
                                else -> if (a.isBlank()) { prefs.question = ""; prefs.answerHash = "" } else { prefs.question = a.trim(); prefs.answerHash = Crypto.hash(b.trim().lowercase()) }
                            }
                            Unit
                        }
                        toast(ctx, "Updated"); onDismiss()
                    }
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SettingsTab(vm: MainVM, nav: NavHostController) {
    val prefs = vm.prefs
    val ctx = LocalContext.current
    val notes by vm.notes.collectAsState()
    val folders by vm.folders.collectAsState()
    var dlg by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<String?>(null) }
    val bioAvail = remember { biometricAvailable(ctx) }
    fun lockLabel(s: Int) = AutoLockOptions.firstOrNull { it.first == s }?.second ?: "$s s"

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 32.dp)) {
        item {
            Text("Settings", style = MaterialTheme.typography.titleLarge)
            SectionTitle("Account & security")
            GlassCard(Modifier.fillMaxWidth()) {
                SettingRow("Change master password", onClick = { dlg = "password" })
                SettingRow("Change PIN", onClick = { dlg = "pin" })
                SettingRow("Biometric unlock", if (bioAvail) "Fingerprint / face" else "Not available on this device") {
                    Switch(checked = prefs.biometric, enabled = bioAvail, onCheckedChange = { on ->
                        if (!on) prefs.biometric = false
                        else ctx.findActivity()?.let { showBiometric(it, "Enable biometrics", { prefs.biometric = true }, { m -> info = m }) }
                    })
                }
                SettingRow("Auto-lock after", lockLabel(prefs.autoLockSec), onClick = { dlg = "autolock" })
                SettingRow("Vault auto-lock after", "${prefs.vaultLockSec / 60} min of inactivity", onClick = { dlg = "vaultlock" })
                SettingRow("Lock when app goes to background") { Switch(checked = prefs.lockOnBg, onCheckedChange = { prefs.lockOnBg = it }) }
                SettingRow("Block screenshots & hide app preview", "Uses Android secure window flag") { Switch(checked = prefs.secureWindow, onCheckedChange = { prefs.secureWindow = it }) }
                SettingRow("Recovery question", if (prefs.question.isEmpty()) "Not set" else "Set", onClick = { dlg = "recovery" })
                SettingRow("Security information", "How your data is protected", onClick = { dlg = "secinfo" })
            }
            SectionTitle("Appearance")
            GlassCard(Modifier.fillMaxWidth()) {
                SettingRow("Themes, RGB, fonts & animations", "Customize the look of AXO VAULT", onClick = { nav.navigate("theme") })
            }
            SectionTitle("Notes")
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Default note colour", fontSize = 16.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NoteColors.forEachIndexed { i, c ->
                        Box(Modifier.size(32.dp).clip(CircleShape).background(if (i == 0) Color.Gray.copy(alpha = 0.4f) else c)
                            .then(if (prefs.defaultColor == i) Modifier.border(3.dp, Color.White, CircleShape) else Modifier).clickable { prefs.defaultColor = i })
                    }
                }
                SettingRow("Default folder", folders.firstOrNull { it.id == prefs.defaultFolder }?.name ?: "None", onClick = { dlg = "folder" })
                SettingRow("Autosave", "Save while typing") { Switch(checked = prefs.autosave, onCheckedChange = { prefs.autosave = it }) }
                SettingRow("Sort notes by", when (prefs.sortBy) { "created" -> "Date created"; "title" -> "Title"; else -> "Last modified" } + if (prefs.sortAsc) " (oldest first)" else " (newest first)", onClick = { dlg = "sort" })
            }
            SectionTitle("Tools")
            GlassCard(Modifier.fillMaxWidth()) {
                SettingRow("Calendar view", onClick = { nav.navigate("calendar") })
                SettingRow("Statistics", onClick = { nav.navigate("stats") })
                SettingRow("Reminders", onClick = { nav.navigate("reminders") })
                SettingRow("Archive", onClick = { nav.navigate("archive") })
                SettingRow("Trash bin", "Items are deleted after 30 days", onClick = { nav.navigate("trash") })
            }
            SectionTitle("Storage")
            GlassCard(Modifier.fillMaxWidth()) {
                val kb = vm.storageBytes() / 1024
                SettingRow("Database", "${notes.size} notes, ${folders.size} folders, ${vm.attachments.collectAsState().value.size} attachments")
                SettingRow("Storage used", if (kb > 1024) "${kb / 1024} MB" else "$kb KB")
                SettingRow("Backup, restore, export & import", onClick = { nav.navigate("backup") })
            }
            SectionTitle("About")
            GlassCard(Modifier.fillMaxWidth()) {
                SettingRow("App name", "AXO VAULT")
                SettingRow("Version", "1.0.0")
                SettingRow("Developer", "AXOLIE")
                SettingRow("Privacy policy", onClick = { dlg = "privacy" })
                SettingRow("App information", "Offline-first. No ads, no tracking, no internet permission.")
            }
            Spacer(Modifier.height(16.dp))
            NeonButton("Lock app now", { Session.lock() }, Modifier.fillMaxWidth(), icon = Icons.Filled.Lock)
        }
    }

    when (dlg) {
        "password", "pin", "recovery" -> SecretDialog(vm, dlg) { dlg = "" }
        "autolock" -> ChoiceDialog("Auto-lock after", AutoLockOptions, prefs.autoLockSec, { prefs.autoLockSec = it }) { dlg = "" }
        "vaultlock" -> ChoiceDialog("Vault auto-lock", listOf(30 to "30 seconds", 60 to "1 minute", 120 to "2 minutes", 300 to "5 minutes", 600 to "10 minutes"), prefs.vaultLockSec, { prefs.vaultLockSec = it }) { dlg = "" }
        "folder" -> ChoiceDialog("Default folder", listOf(-1L to "None") + folders.filter { !it.isVault }.map { it.id to it.name }, prefs.defaultFolder, { prefs.defaultFolder = it }) { dlg = "" }
        "sort" -> ChoiceDialog("Sort notes by", listOf("modified" to "Last modified", "created" to "Date created", "title" to "Title"), prefs.sortBy, { prefs.sortBy = it }) { dlg = "" }
        "secinfo" -> AlertDialog(onDismissRequest = { dlg = "" }, title = { Text("How your data is protected") },
            text = { Text("• Your password and PIN are stored only as salted PBKDF2 hashes.\n• Private vault notes and attachments are encrypted with AES-256-GCM. The key is random and wrapped by the Android Keystore.\n• Five wrong attempts trigger increasing wait times. Nothing is ever auto-deleted.\n• Backups are encrypted with a password you choose. If you lose that password, the backup cannot be opened.\n\nLimits: if the phone's Keystore is reset, the app data is cleared, or you uninstall the app, encrypted notes cannot be recovered without a backup. A security question lets you reset the password, but nobody - including the developer - can recover lost encrypted data.") },
            confirmButton = { TextButton(onClick = { dlg = "" }) { Text("OK") } })
        "privacy" -> AlertDialog(onDismissRequest = { dlg = "" }, title = { Text("Privacy policy") },
            text = { Text("AXO VAULT stores everything locally on your device. It has no internet permission, no accounts, no analytics and no ads. Nothing is sent to the developer or any third party. Cloud sync does not exist in this version. Data leaves the phone only when you export, share or back up a note yourself.") },
            confirmButton = { TextButton(onClick = { dlg = "" }) { Text("OK") } })
    }
    info?.let { m -> AlertDialog(onDismissRequest = { info = null }, text = { Text(m) }, confirmButton = { TextButton(onClick = { info = null }) { Text("OK") } }) }
}
