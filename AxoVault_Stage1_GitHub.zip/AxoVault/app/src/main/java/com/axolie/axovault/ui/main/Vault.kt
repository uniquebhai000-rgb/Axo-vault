package com.axolie.axovault.ui.main

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.axolie.axovault.data.*
import com.axolie.axovault.security.*
import com.axolie.axovault.ui.auth.*
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.theme.*
import com.axolie.axovault.util.*
import com.axolie.axovault.navigation.editor

@Composable
fun VaultTab(vm: MainVM, nav: NavHostController) {
    if (!Session.vaultUnlocked) VaultGate(vm) else VaultContent(vm, nav)
}

@Composable
fun VaultGate(vm: MainVM) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(16.dp))
        Box(Modifier.size(90.dp).rgbBorder(CircleShape, 3.dp), contentAlignment = Alignment.Center) { Icon(Icons.Filled.Lock, null, Modifier.size(40.dp), tint = Axo.NeonPurple) }
        Spacer(Modifier.height(14.dp))
        Text("Private Vault", style = MaterialTheme.typography.titleLarge)
        Text("Verify again to open your encrypted notes", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        Spacer(Modifier.height(24.dp))
        AuthPanel(vm, onSuccess = { Session.unlockVault() }, autoBiometric = false)
    }
}

@Composable
fun VaultContent(vm: MainVM, nav: NavHostController) {
    val notes by vm.notes.collectAsState()
    val folders by vm.folders.collectAsState()
    val vf = folders.filter { it.isVault }
    var sel by remember { mutableStateOf<Long?>(null) }
    var creating by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<FolderEntity?>(null) }
    var del by remember { mutableStateOf<FolderEntity?>(null) }
    val list = notes.filter { it.encrypted && it.trashedAt == null && (sel == null || it.folderId == sel) }.sortedByDescending { it.modifiedAt }
    val selFolder = vf.firstOrNull { it.id == sel }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Lock, null, tint = Axo.NeonPurple)
            Spacer(Modifier.width(8.dp))
            Text("Private Vault", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = { Session.vaultUnlocked = false }) { Text("Lock now", color = Axo.RgbPink) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonChip("All", sel == null, { sel = null })
            vf.forEach { f -> NeonChip(f.name, sel == f.id, { sel = f.id }, FolderIcons[f.icon]) }
            NeonChip("New folder", false, { creating = true }, Icons.Filled.Add)
        }
        if (selFolder != null) Row(Modifier.padding(horizontal = 8.dp)) {
            TextButton(onClick = { edit = selFolder }) { Text("Edit folder") }
            TextButton(onClick = { del = selFolder }) { Text("Delete folder", color = Axo.RgbPink) }
        }
        Box(Modifier.weight(1f)) {
            if (list.isEmpty()) EmptyState(Icons.Filled.Lock, "Vault is empty", "Notes here are encrypted with AES-256-GCM. Create one or move a note in from its menu.")
            else NotesList(vm, list, false, nav)
            NeonButton("New private note", { vm.pendingFolder = sel ?: -1L; nav.editor(-1, "v") }, Modifier.align(Alignment.BottomEnd).padding(16.dp), icon = Icons.Filled.Add)
        }
    }
    if (creating) FolderDialog(null, true, { vm.saveFolder(it) }) { creating = false }
    edit?.let { f -> FolderDialog(f, true, { vm.saveFolder(it) }) { edit = null } }
    del?.let { f ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("Delete private folder?") },
            text = { Text("Notes inside stay in the vault but become unfiled.") },
            confirmButton = { TextButton(onClick = { vm.deleteFolder(f); if (sel == f.id) sel = null; del = null }) { Text("Delete", color = Axo.RgbPink) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("Cancel") } })
    }
}
