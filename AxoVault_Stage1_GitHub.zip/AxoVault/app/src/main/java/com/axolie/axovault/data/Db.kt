package com.axolie.axovault.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val color: Int = 0,
    val tags: String = "",
    val folderId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val modifiedAt: Long = System.currentTimeMillis(),
    val pinned: Boolean = false,
    val favorite: Boolean = false,
    val archived: Boolean = false,
    val trashedAt: Long? = null,
    val encrypted: Boolean = false,
    val reminderAt: Long? = null,
    val reminderDone: Boolean = false
) {
    fun tagList(): List<String> = tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }
}

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val color: Int = 0,
    val icon: String = "folder",
    val isVault: Boolean = false
)

@Entity(tableName = "attachments")
data class AttachmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val noteId: Long,
    val name: String,
    val mime: String,
    val path: String,
    val encrypted: Boolean
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes") fun notes(): Flow<List<NoteEntity>>
    @Query("SELECT * FROM notes WHERE id = :id") suspend fun note(id: Long): NoteEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(n: NoteEntity): Long
    @Query("DELETE FROM notes WHERE id = :id") suspend fun deleteNote(id: Long)
    @Query("SELECT * FROM notes WHERE reminderAt IS NOT NULL AND reminderDone = 0 AND trashedAt IS NULL")
    suspend fun pendingReminders(): List<NoteEntity>
    @Query("SELECT * FROM notes WHERE trashedAt IS NOT NULL AND trashedAt < :before")
    suspend fun trashedBefore(before: Long): List<NoteEntity>

    @Query("SELECT * FROM folders ORDER BY name") fun folders(): Flow<List<FolderEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertFolder(f: FolderEntity): Long
    @Query("DELETE FROM folders WHERE id = :id") suspend fun deleteFolder(id: Long)
    @Query("UPDATE notes SET folderId = NULL WHERE folderId = :id") suspend fun clearFolder(id: Long)

    @Query("SELECT * FROM attachments") fun attachments(): Flow<List<AttachmentEntity>>
    @Query("SELECT * FROM attachments WHERE noteId = :id") suspend fun attachmentsOf(id: Long): List<AttachmentEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAttachment(a: AttachmentEntity): Long
    @Query("DELETE FROM attachments WHERE id = :id") suspend fun deleteAttachment(id: Long)
}

@Database(entities = [NoteEntity::class, FolderEntity::class, AttachmentEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): NoteDao

    companion object {
        fun get(ctx: Context): AppDb =
            Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "axo.db").build()
    }
}
