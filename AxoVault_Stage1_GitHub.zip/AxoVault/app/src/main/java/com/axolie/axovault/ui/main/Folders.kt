package com.axolie.axovault.ui.main

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.axolie.axovault.data.*
import com.axolie.axovault.security.*
import com.axolie.axovault.ui.auth.*
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.theme.*
import com.axolie.axovault.util.*
import androidx.compose.foundation.lazy.grid.*
import com.axolie.axovault.navigation.editor

@Composable
fun FolderDialog(initial: FolderEntity?, vault: Boolean, onSave: (FolderEntity) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var color by remember { mutableStateOf(initial?.color ?: 0) }
    var icon by remember { mutableStateOf(initial?.icon ?: if (vault) "lock" else "folder") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New folder" else "Edit folder") },
        text = {
            Column {
                NeonField(name, { name = it.take(30) }, "Folder name")
                SectionTitle("Colour")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FolderColors.forEachIndexed { i, c ->
                        Box(Modifier.size(34.dp).clip(CircleShape).background(c).then(if (i == color) Modifier.border(3.dp, Color.White, CircleShape) else Modifier).clickable { color = i })
                    }
                }
                SectionTitle("Icon")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FolderIcons.forEach { (k, v) ->
                        Box(Modifier.size(40.dp).clip(CircleShape).background(if (k == icon) Axo.Cyan else Color.Transparent).border(1.dp, Axo.TextSecondary, CircleShape).clickable { icon = k }, contentAlignment = Alignment.Center) {
                            Icon(v, k, tint = if (k == icon) Color.Black else MaterialTheme.colorScheme.onBackground)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                onSave((initial ?: FolderEntity(name = "", isVault = vault)).copy(name = name.trim(), color = color, icon = icon)); onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun FoldersTab(vm: MainVM, nav: NavHostController) {
    val folders by vm.folders.collectAsState()
    val notes by vm.notes.collectAsState()
    var q by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<FolderEntity?>(null) }
    var creating by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf<FolderEntity?>(null) }
    val shown = folders.filter { !it.isVault && it.name.contains(q.trim(), ignoreCase = true) }

    Column(Modifier.fillMaxSize()) {
        Text("Folders", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(start = 16.dp, top = 10.dp))
        NeonField(q, { q = it }, "Search folders", Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        Box(Modifier.weight(1f)) {
            if (shown.isEmpty()) EmptyState(Icons.Filled.Folder, "No folders", "Create folders to organise your notes.")
            else LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(shown, key = { it.id }) { f ->
                    var menu by remember { mutableStateOf(false) }
                    val count = notes.count { it.folderId == f.id && it.trashedAt == null && !it.encrypted }
                    val c = FolderColors.getOrElse(f.color) { Axo.Cyan }
                    GlassCard(Modifier.fillMaxWidth(), tint = c, onClick = { nav.navigate("folder/${f.id}") }, onLongClick = { menu = true }) {
                        Row {
                            Icon(FolderIcons[f.icon] ?: Icons.Filled.Folder, null, tint = c, modifier = Modifier.size(32.dp))
                            Spacer(Modifier.weight(1f))
                            Box {
                                IconButton(onClick = { menu = true }, Modifier.size(28.dp)) { Icon(Icons.Filled.MoreVert, "Menu") }
                                DropdownMenu(menu, { menu = false }) {
                                    DropdownMenuItem(text = { Text("Rename / edit") }, onClick = { menu = false; edit = f })
                                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; del = f })
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(f.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("$count notes", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                    }
                }
            }
            NeonButton("New folder", { creating = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp), icon = Icons.Filled.CreateNewFolder)
        }
    }
    if (creating) FolderDialog(null, false, { vm.saveFolder(it) }) { creating = false }
    edit?.let { f -> FolderDialog(f, false, { vm.saveFolder(it) }) { edit = null } }
    del?.let { f ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("Delete folder?") },
            text = { Text("The folder \"${f.name}\" will be deleted. Its notes are kept and become unfiled.") },
            confirmButton = { TextButton(onClick = { vm.deleteFolder(f); del = null }) { Text("Delete", color = Axo.RgbPink) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("Cancel") } })
    }
}

@Composable
fun FolderScreen(vm: MainVM, nav: NavHostController, fid: Long) {
    val folders by vm.folders.collectAsState()
    val notes by vm.notes.collectAsState()
    val f = folders.firstOrNull { it.id == fid }
    val list = notes.filter { it.folderId == fid && it.trashedAt == null && !it.encrypted }.sortedByDescending { it.modifiedAt }
    Screen(f?.name ?: "Folder", { nav.popBackStack() }) {
        Box(Modifier.weight(1f)) {
            if (list.isEmpty()) EmptyState(Icons.Filled.Folder, "Empty folder", "Add a note to this folder.")
            else NotesList(vm, list, false, nav)
            NeonButton("New note", { vm.pendingFolder = fid; nav.editor(-1) }, Modifier.align(Alignment.BottomEnd).padding(16.dp), icon = Icons.Filled.Add)
        }
    }
}
