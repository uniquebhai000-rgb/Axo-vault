package com.axolie.axovault.ui.main

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.axolie.axovault.data.*
import com.axolie.axovault.security.*
import com.axolie.axovault.ui.auth.*
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.theme.*
import com.axolie.axovault.util.*
import androidx.compose.foundation.lazy.staggeredgrid.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import com.axolie.axovault.navigation.editor

@Composable
fun NoteCard(vm: MainVM, e: NoteEntity, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val locked = e.encrypted && !Session.vaultUnlocked
    val title = vm.titleOf(e)
    val body = if (locked) "Private note" else Markup.plain(vm.contentOf(e)).take(160)
    var menu by remember { mutableStateOf(false) }
    val muted = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
    GlassCard(modifier.fillMaxWidth(), tint = NoteColors.getOrElse(e.color) { Color.Transparent }, onClick = onOpen, onLongClick = { menu = true }) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (body.isNotBlank()) Text(body, maxLines = 3, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, color = muted)
            }
            Box {
                IconButton(onClick = { menu = true }, Modifier.size(32.dp)) { Icon(Icons.Filled.MoreVert, "Menu") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(if (e.pinned) "Unpin" else "Pin") }, onClick = { menu = false; vm.togglePin(e) })
                    DropdownMenuItem(text = { Text(if (e.favorite) "Remove favourite" else "Favourite") }, onClick = { menu = false; vm.toggleFav(e) })
                    DropdownMenuItem(text = { Text(if (e.archived) "Unarchive" else "Archive") }, onClick = { menu = false; vm.toggleArchive(e) })
                    DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; vm.duplicate(e) })
                    DropdownMenuItem(text = { Text("Move to trash") }, onClick = { menu = false; vm.trash(e) })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (e.pinned) Icon(Icons.Filled.PushPin, "Pinned", Modifier.size(14.dp), tint = Axo.Cyan)
            if (e.favorite) Icon(Icons.Filled.Star, "Favourite", Modifier.size(14.dp), tint = Axo.RgbPink)
            if (e.reminderAt != null && !e.reminderDone) Icon(Icons.Filled.Alarm, "Reminder", Modifier.size(14.dp), tint = Axo.NeonGreen)
            if (e.encrypted) Icon(Icons.Filled.Lock, "Private", Modifier.size(14.dp), tint = Axo.NeonPurple)
            val tags = e.tagList().take(2).joinToString(" ") { "#$it" }
            if (tags.isNotEmpty()) Text(" $tags", fontSize = 12.sp, color = Axo.Cyan, maxLines = 1)
            Spacer(Modifier.weight(1f))
            Text(fmtDate(e.modifiedAt), fontSize = 11.sp, color = muted, maxLines = 1)
        }
    }
}

@Composable
fun NotesList(vm: MainVM, list: List<NoteEntity>, sticky: Boolean, nav: NavHostController, bottomPad: Int = 96) {
    if (sticky) {
        LazyVerticalStaggeredGrid(
            columns = StaggeredGridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, bottomPad.dp),
            verticalItemSpacing = 10.dp, horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) { items(list, key = { it.id }) { NoteCard(vm, it, { nav.editor(it.id) }) } }
    } else {
        LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, bottomPad.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { NoteCard(vm, it, { nav.editor(it.id) }) }
        }
    }
}

fun filterNotes(vm: MainVM, notes: List<NoteEntity>, folders: List<FolderEntity>, filter: String, q: String): List<NoteEntity> {
    val fmap = folders.associateBy { it.id }
    val now = System.currentTimeMillis()
    var l = notes.filter { it.trashedAt == null }
    l = when (filter) {
        "all" -> l.filter { !it.encrypted && !it.archived }
        "private" -> l.filter { it.encrypted }
        "fav" -> l.filter { it.favorite && !it.encrypted }
        "pinned" -> l.filter { it.pinned && !it.encrypted }
        "archived" -> l.filter { it.archived && !it.encrypted }
        "recent" -> l.filter { !it.encrypted && !it.archived && it.modifiedAt > now - 7 * 86_400_000L }
        else -> l
    }
    if (q.isNotBlank()) {
        val k = q.trim().lowercase()
        l = l.filter {
            val plainHit = !it.encrypted && (it.title.lowercase().contains(k) || it.content.lowercase().contains(k))
            val tagHit = it.tags.lowercase().contains(k)
            val folderHit = fmap[it.folderId]?.name?.lowercase()?.contains(k) == true
            val vaultHit = it.encrypted && Session.vaultUnlocked && (vm.titleOf(it).lowercase().contains(k) || vm.contentOf(it).lowercase().contains(k))
            plainHit || tagHit || folderHit || vaultHit
        }
    }
    val cmp: Comparator<NoteEntity> = when (vm.prefs.sortBy) {
        "created" -> compareBy<NoteEntity> { it.createdAt }
        "title" -> compareBy<NoteEntity> { vm.titleOf(it).lowercase() }
        else -> compareBy<NoteEntity> { it.modifiedAt }
    }
    return l.sortedWith(if (vm.prefs.sortAsc) cmp else cmp.reversed()).sortedByDescending { it.pinned }
}

@Composable
fun NotesTab(vm: MainVM, nav: NavHostController) {
    val notes by vm.notes.collectAsState()
    val folders by vm.folders.collectAsState()
    val prefs = vm.prefs
    var filter by remember { mutableStateOf("all") }
    var sticky by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var showAuth by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(vm.focusSearch) { if (vm.focusSearch) { runCatching { focus.requestFocus() }; vm.focusSearch = false } }
    val unlocked = Session.vaultUnlocked
    val list = remember(notes, folders, filter, vm.query, prefs.sortBy, prefs.sortAsc, unlocked) { filterNotes(vm, notes, folders, filter, vm.query) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("All Notes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            IconButton(onClick = { sticky = !sticky }) { Icon(if (sticky) Icons.Filled.ViewAgenda else Icons.Filled.GridView, "Switch view") }
            Box {
                IconButton(onClick = { sortMenu = true }) { Icon(Icons.Filled.SwapVert, "Sort") }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf("modified" to "Last modified", "created" to "Date created", "title" to "Title").forEach { (k, l) ->
                        DropdownMenuItem(text = { Text((if (prefs.sortBy == k) "• " else "") + l) }, onClick = { prefs.sortBy = k; sortMenu = false })
                    }
                    DropdownMenuItem(text = { Text(if (prefs.sortAsc) "Order: oldest first" else "Order: newest first") }, onClick = { prefs.sortAsc = !prefs.sortAsc; sortMenu = false })
                }
            }
        }
        NeonField(vm.query, { vm.query = it }, "Search titles, content, tags, folders", Modifier.padding(horizontal = 16.dp, vertical = 6.dp).focusRequester(focus))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("all" to "All", "private" to "Private", "fav" to "Favourites", "pinned" to "Pinned", "archived" to "Archived", "recent" to "Recent").forEach { (k, l) ->
                NeonChip(l, filter == k, { filter = k })
            }
        }
        Box(Modifier.weight(1f)) {
            when {
                filter == "private" && !unlocked -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    EmptyState(Icons.Filled.Lock, "Vault is locked", "Private notes stay hidden until you unlock the vault.")
                    NeonButton("Unlock vault", { showAuth = true })
                }
                list.isEmpty() -> EmptyState(Icons.Filled.Description, if (vm.query.isBlank()) "Nothing here yet" else "No results", if (vm.query.isBlank()) "Tap New note to write your first note." else "Try different words or another filter.")
                else -> NotesList(vm, list, sticky, nav)
            }
            NeonButton("New note", { nav.editor(-1) }, Modifier.align(Alignment.BottomEnd).padding(16.dp), icon = Icons.Filled.Add)
        }
    }
    if (showAuth) VaultAuthDialog(vm, { showAuth = false }, { showAuth = false })
}
