package com.axolie.axovault.security

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import kotlin.reflect.KProperty

/** Settings in SharedPreferences. Only hashes and a Keystore-wrapped key are stored - never plain secrets. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("axo_prefs", Context.MODE_PRIVATE)

    inner class Pref<T : Any>(private val key: String, private val def: T) {
        private val s = mutableStateOf(read())

        @Suppress("UNCHECKED_CAST")
        private fun read(): T = when (def) {
            is String -> sp.getString(key, def) as T
            is Boolean -> sp.getBoolean(key, def) as T
            is Int -> sp.getInt(key, def) as T
            is Long -> sp.getLong(key, def) as T
            is Float -> sp.getFloat(key, def) as T
            else -> def
        }

        operator fun getValue(r: Any?, p: KProperty<*>): T = s.value
        operator fun setValue(r: Any?, p: KProperty<*>, v: T) {
            s.value = v
            val ed = sp.edit()
            when (v) {
                is String -> ed.putString(key, v)
                is Boolean -> ed.putBoolean(key, v)
                is Int -> ed.putInt(key, v)
                is Long -> ed.putLong(key, v)
                is Float -> ed.putFloat(key, v)
            }
            ed.apply()
        }
    }

    var configured by Pref("configured", false)
    var passHash by Pref("passHash", "")
    var pinHash by Pref("pinHash", "")
    var pinLen by Pref("pinLen", 4)
    var question by Pref("question", "")
    var answerHash by Pref("answerHash", "")
    var biometric by Pref("biometric", false)
    var autoLockSec by Pref("autoLockSec", 60)
    var vaultLockSec by Pref("vaultLockSec", 120)
    var lockOnBg by Pref("lockOnBg", true)
    var secureWindow by Pref("secureWindow", true)
    var failCount by Pref("failCount", 0)
    var lockedUntil by Pref("lockedUntil", 0L)
    var wrappedKey by Pref("wrappedKey", "")

    var themeMode by Pref("themeMode", "rgb")
    var customColor by Pref("customColor", 0xFF00E5FF.toInt())
    var borderAnim by Pref("borderAnim", true)
    var glow by Pref("glow", 0.6f)
    var animSpeed by Pref("animSpeed", 1f)
    var cardAlpha by Pref("cardAlpha", 0.10f)
    var corner by Pref("corner", 20)
    var fontScale by Pref("fontScale", 1f)
    var darkMode by Pref("darkMode", "dark")
    var haptics by Pref("haptics", true)

    var defaultColor by Pref("defaultColor", 0)
    var defaultFolder by Pref("defaultFolder", -1L)
    var autosave by Pref("autosave", true)
    var sortBy by Pref("sortBy", "modified")
    var sortAsc by Pref("sortAsc", false)
}
