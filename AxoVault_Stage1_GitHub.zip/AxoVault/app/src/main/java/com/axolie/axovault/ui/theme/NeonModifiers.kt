package com.axolie.axovault.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** One shared animation phase for the whole app (battery friendly: read only while drawing). */
val LocalPhase = compositionLocalOf<State<Float>> { mutableFloatStateOf(0f) }

fun rgbColorsAt(phase: Float, palette: List<Color> = Axo.RgbPalette): List<Color> {
    val n = palette.size
    return (0..n).map { k ->
        val pos = phase * n + k
        val i = pos.toInt()
        val frac = pos - i
        lerp(palette[i % n], palette[(i + 1) % n], frac)
    }
}

@Composable
fun rememberPhaseState(durationMs: Int, animated: Boolean): State<Float> {
    if (!animated) return remember { mutableFloatStateOf(0f) }
    val t = rememberInfiniteTransition(label = "phase")
    return t.animateFloat(0f, 1f, infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart), label = "ph")
}

@Composable
fun rememberRgbPhase(durationMs: Int = 5000): Float {
    val t = rememberInfiniteTransition(label = "rgbPhase")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    return phase
}

/** Animated RGB neon outline with a soft glow. Works on any shape. */
fun Modifier.rgbBorder(
    shape: Shape = RoundedCornerShape(20.dp),
    width: Dp = 2.dp,
    @Suppress("UNUSED_PARAMETER") durationMs: Int = 5000
): Modifier = composed {
    val st = LocalStyle.current
    val ph = LocalPhase.current
    drawWithContent {
        drawContent()
        val colors = rgbColorsAt(ph.value, st.palette)
        val outline = shape.createOutline(size, layoutDirection, this)
        val center = Offset(size.width / 2f, size.height / 2f)
        if (st.glow > 0.01f) {
            drawOutline(outline, Brush.sweepGradient(colors.map { it.copy(alpha = st.glow * 0.3f) }, center), style = Stroke(width.toPx() * 4))
        }
        drawOutline(outline, Brush.sweepGradient(colors, center), style = Stroke(width.toPx()))
    }
}
