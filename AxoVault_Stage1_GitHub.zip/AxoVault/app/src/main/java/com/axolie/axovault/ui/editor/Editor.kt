package com.axolie.axovault.ui.editor

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.axolie.axovault.data.*
import com.axolie.axovault.security.Session
import com.axolie.axovault.ui.auth.VaultAuthDialog
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.theme.*
import com.axolie.axovault.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun Tb(icon: ImageVector, desc: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, Modifier.size(40.dp)) { Icon(icon, desc, Modifier.size(22.dp)) }
}

@Composable
private fun AttachThumb(vm: MainVM, a: AttachmentEntity, onClick: () -> Unit) {
    var bmp by remember(a.id) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(a.id) {
        if (a.mime.startsWith("image/")) bmp = withContext(Dispatchers.IO) { runCatching { Media.decode(vm.readAttachment(a), 200) }.getOrNull() }
    }
    Box(Modifier.size(84.dp).clip(RoundedCornerShape(14.dp)).border(1.dp, Axo.Cyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), a.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Description, null, tint = Axo.Cyan)
            Text(a.name, fontSize = 10.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 4.dp))
        }
    }
}

@Composable
private fun AttachViewer(vm: MainVM, a: AttachmentEntity, onExport: () -> Unit, onDelete: () -> Unit, onClose: () -> Unit) {
    var bmp by remember(a.id) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(a.id) {
        if (a.mime.startsWith("image/")) bmp = withContext(Dispatchers.IO) { runCatching { Media.decode(vm.readAttachment(a), 1200) }.getOrNull() }
    }
    AlertDialog(
        onDismissRequest = onClose, title = { Text(a.name, maxLines = 1) },
        text = {
            Column {
                val b = bmp
                if (b != null) Image(b.asImageBitmap(), a.name, Modifier.fillMaxWidth().heightIn(max = 360.dp), contentScale = ContentScale.Fit)
                else Text("${a.mime}")
                if (a.encrypted) Text("Stored encrypted. Export saves an unencrypted copy.", fontSize = 12.sp, color = Axo.RgbPink)
            }
        },
        confirmButton = { Row { TextButton(onClick = onExport) { Text("Export") }; TextButton(onClick = onDelete) { Text("Delete", color = Axo.RgbPink) } } },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable
fun EditorScreen(vm: MainVM, noteId: Long, mode: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = vm.prefs
    val st = LocalStyle.current
    val clip = LocalClipboardManager.current
    val folders by vm.folders.collectAsState()
    val allAtt by vm.attachments.collectAsState()
    val onBg = MaterialTheme.colorScheme.onBackground
    val transformation = remember(onBg) { MarkupTransformation(onBg.copy(alpha = 0.3f)) }

    var entity by remember { mutableStateOf<NoteEntity?>(null) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf(TextFieldValue("")) }
    var loaded by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(true) }
    var lastSaved by remember { mutableStateOf<Triple<NoteEntity?, String, String>?>(null) }
    var preview by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf(false) }
    var linkDlg by remember { mutableStateOf(false) }
    var viewAtt by remember { mutableStateOf<AttachmentEntity?>(null) }
    var exportAtt by remember { mutableStateOf<AttachmentEntity?>(null) }
    var confirmExport by remember { mutableStateOf<String?>(null) }
    var exportBytes by remember { mutableStateOf<ByteArray?>(null) }
    var vaultAuth by remember { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }

    LaunchedEffect(noteId) {
        if (noteId > 0) {
            val e = vm.getNote(noteId)
            if (e == null || (e.encrypted && !Session.vaultUnlocked)) { onBack(); return@LaunchedEffect }
            entity = e; title = vm.titleOf(e); content = TextFieldValue(vm.contentOf(e))
        } else {
            val vault = mode == "v"
            val tpl = if (mode.startsWith("t_")) Templates.byKey(mode.removePrefix("t_")) else null
            val pf = vm.pendingFolder
            val folder = when {
                pf > 0 -> pf
                !vault && prefs.defaultFolder > 0 && folders.any { it.id == prefs.defaultFolder } -> prefs.defaultFolder
                else -> null
            }
            entity = NoteEntity(color = prefs.defaultColor, folderId = folder, encrypted = vault)
            if (tpl != null) { title = tpl.title; content = TextFieldValue(tpl.body) }
            vm.pendingFolder = -1L
        }
        lastSaved = Triple(entity, title, content.text)
        loaded = true
    }

    val nid = entity?.id ?: 0L
    val atts = if (nid == 0L) emptyList() else allAtt.filter { it.noteId == nid }
    val dirty = loaded && entity != null && Triple(entity, title, content.text) != lastSaved

    suspend fun saveNow(force: Boolean = false): Boolean {
        val e = entity ?: return false
        val t = title
        val c = content.text
        if (e.id == 0L && t.isBlank() && c.isBlank() && !force) return false
        val id = vm.persist(e, t, c)
        val ne = if (id != e.id) e.copy(id = id) else e
        entity = if (entity == e) ne else entity?.copy(id = id)
        lastSaved = Triple(ne, t, c)
        saved = true
        return true
    }

    LaunchedEffect(entity, title, content.text, loaded) {
        if (!loaded || entity == null) return@LaunchedEffect
        if (lastSaved == Triple(entity, title, content.text)) { saved = true; return@LaunchedEffect }
        saved = false
        if (prefs.autosave) { delay(700); saveNow() }
    }
    LaunchedEffect(content.text) { Session.touch() }

    // ---- undo / redo history
    val hist = remember { mutableStateListOf<TextFieldValue>() }
    var hIdx by remember { mutableIntStateOf(0) }
    var applying by remember { mutableStateOf(false) }
    LaunchedEffect(loaded) { if (loaded && hist.isEmpty()) { hist.add(content); hIdx = 0 } }
    fun commitHistory() {
        if (hist.isNotEmpty() && hist[hIdx].text != content.text) {
            while (hist.size > hIdx + 1) hist.removeAt(hist.size - 1)
            hist.add(content)
            if (hist.size > 100) hist.removeAt(0)
            hIdx = hist.size - 1
        }
    }
    LaunchedEffect(content.text) {
        if (!loaded) return@LaunchedEffect
        if (applying) { applying = false; return@LaunchedEffect }
        delay(500)
        commitHistory()
    }
    fun undo() { commitHistory(); if (hIdx > 0) { hIdx--; applying = true; content = hist[hIdx] } }
    fun redo() { if (hIdx < hist.size - 1) { hIdx++; applying = true; content = hist[hIdx] } }

    fun flushNow() {
        val e = entity
        if (loaded && e != null && prefs.autosave && Triple(e, title, content.text) != lastSaved) vm.flush(e, title, content.text)
    }
    DisposableEffect(Unit) { onDispose { flushNow() } }
    BackHandler(enabled = !prefs.autosave && dirty) { discard = true }

    val attachPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            saveNow(true)
            val e = entity
            if (e != null && e.id > 0) {
                val ok = vm.addAttachment(uri, e.id, e.encrypted)
                toast(ctx, if (ok) "Attached" else "Could not attach (max 25 MB)")
            }
        }
    }
    val attSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val a = exportAtt
        if (uri != null && a != null) scope.launch {
            val bytes = withContext(Dispatchers.IO) { runCatching { vm.readAttachment(a) }.getOrNull() }
            toast(ctx, if (bytes != null && ctx.writeUri(uri, bytes)) "Exported" else "Export failed")
        }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun ensureNotif() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val txtLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val b = exportBytes
        if (uri != null && b != null) toast(ctx, if (ctx.writeUri(uri, b)) "Exported" else "Export failed")
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val b = exportBytes
        if (uri != null && b != null) toast(ctx, if (ctx.writeUri(uri, b)) "Exported" else "Export failed")
    }
    fun doExport(kind: String) {
        val text = vm.noteText(title, content.text, entity?.createdAt)
        when (kind) {
            "share" -> Export.share(ctx, title.ifBlank { "Note" }, text)
            "txt" -> { exportBytes = text.toByteArray(); Session.external(); txtLauncher.launch(safeName(title) + ".txt") }
            else -> { exportBytes = Export.pdf(title, Markup.plain(content.text)); Session.external(); pdfLauncher.launch(safeName(title) + ".pdf") }
        }
    }
    fun requestExport(kind: String) { if (entity?.encrypted == true) confirmExport = kind else doExport(kind) }
    fun toggleVault() {
        scope.launch {
            saveNow(true)
            val e = entity ?: return@launch
            val n = vm.moveVault(e, !e.encrypted)
            entity = n
            lastSaved = Triple(n, title, content.text)
            toast(ctx, if (n.encrypted) "Moved to vault" else "Moved out of vault")
        }
    }
    fun attemptBack() { if (!prefs.autosave && dirty) discard = true else onBack() }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { attemptBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            if (entity?.encrypted == true) Icon(Icons.Filled.Lock, "Private", Modifier.size(16.dp), tint = Axo.NeonPurple)
            Spacer(Modifier.weight(1f))
            if (!prefs.autosave) TextButton(onClick = { scope.launch { saveNow(); toast(ctx, "Saved") } }) { Text("Save") }
            Text(if (saved) "Saved ✓" else if (prefs.autosave) "Saving…" else "Unsaved", fontSize = 12.sp, color = if (saved) Axo.NeonGreen else Axo.RgbPink)
            IconButton(onClick = { preview = !preview }) { Icon(if (preview) Icons.Filled.Edit else Icons.Filled.Visibility, "Preview") }
            IconButton(onClick = { sheet = true }) { Icon(Icons.Filled.MoreVert, "Details") }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            BasicTextField(
                value = title, onValueChange = { title = it },
                textStyle = TextStyle(color = onBg, fontSize = 26.sp, fontWeight = FontWeight.Bold),
                cursorBrush = SolidColor(st.accent), singleLine = true, modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner -> Box { if (title.isEmpty()) Text("Title", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = onBg.copy(alpha = 0.35f)); inner() } }
            )
            entity?.let { e ->
                Text("Created ${fmtDate(e.createdAt)}" + if (e.id > 0) " · Edited ${fmtDate(e.modifiedAt)}" else "", fontSize = 11.sp, color = onBg.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))
            }
            if (preview) {
                MarkupView(content.text) { idx -> content = content.copy(text = Markup.toggleCheck(content.text, idx)) }
            } else {
                BasicTextField(
                    value = content, onValueChange = { content = Markup.autoContinue(content, it) },
                    textStyle = TextStyle(color = onBg, fontSize = 16.sp, lineHeight = 24.sp),
                    visualTransformation = transformation,
                    cursorBrush = SolidColor(st.accent), modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp),
                    decorationBox = { inner -> Box { if (content.text.isEmpty()) Text("Start writing…", color = onBg.copy(alpha = 0.35f)); inner() } }
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ATTACHMENTS (${atts.size})", fontSize = 12.sp, letterSpacing = 2.sp, color = onBg.copy(alpha = 0.6f), modifier = Modifier.weight(1f))
                TextButton(onClick = { Session.external(); attachPicker.launch(arrayOf("*/*")) }) { Icon(Icons.Filled.Attachment, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Attach image / file") }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                atts.forEach { a -> AttachThumb(vm, a) { viewAtt = a } }
            }
            Spacer(Modifier.height(24.dp))
        }
        if (!preview) {
            var colorMenu by remember { mutableStateOf(false) }
            var sizeMenu by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
                Tb(Icons.Filled.Undo, "Undo") { undo() }
                Tb(Icons.Filled.Redo, "Redo") { redo() }
                Tb(Icons.Filled.FormatBold, "Bold") { content = Markup.wrap(content, "**") }
                Tb(Icons.Filled.FormatItalic, "Italic") { content = Markup.wrap(content, "*") }
                Tb(Icons.Filled.FormatUnderlined, "Underline") { content = Markup.wrap(content, "__") }
                Tb(Icons.Filled.FormatStrikethrough, "Strikethrough") { content = Markup.wrap(content, "~~") }
                Tb(Icons.Filled.Title, "Heading") { content = Markup.cycleHeading(content) }
                Tb(Icons.Filled.FormatListBulleted, "Bullets") { content = Markup.setBlock(content, "- ") }
                Tb(Icons.Filled.FormatListNumbered, "Numbered") { content = Markup.setBlock(content, "1. ") }
                Tb(Icons.Filled.CheckBox, "Checklist") { content = Markup.setBlock(content, "- [ ] ") }
                Tb(Icons.Filled.FormatAlignLeft, "Align left") { content = Markup.setAlign(content, "l") }
                Tb(Icons.Filled.FormatAlignCenter, "Align centre") { content = Markup.setAlign(content, "c") }
                Tb(Icons.Filled.FormatAlignRight, "Align right") { content = Markup.setAlign(content, "r") }
                Box {
                    Tb(Icons.Filled.FormatSize, "Font size") { sizeMenu = true }
                    DropdownMenu(sizeMenu, { sizeMenu = false }) {
                        listOf(12, 14, 18, 24, 32).forEach { s -> DropdownMenuItem(text = { Text("$s") }, onClick = { sizeMenu = false; content = Markup.wrap(content, "{s:$s|", "}") }) }
                    }
                }
                Box {
                    Tb(Icons.Filled.FormatColorText, "Text colour") { colorMenu = true }
                    DropdownMenu(colorMenu, { colorMenu = false }) {
                        listOf("FF2DAA", "B026FF", "2979FF", "00E5FF", "39FF14", "FFB300", "FF4D4D", "FFFFFF").forEach { hex ->
                            DropdownMenuItem(text = { Box(Modifier.size(width = 60.dp, height = 18.dp).clip(RoundedCornerShape(6.dp)).background(Color(android.graphics.Color.parseColor("#$hex")))) },
                                onClick = { colorMenu = false; content = Markup.wrap(content, "{c:#$hex|", "}") })
                        }
                    }
                }
                Tb(Icons.Filled.FormatColorFill, "Highlight") { content = Markup.wrap(content, "==") }
                Tb(Icons.Filled.Link, "Link") { linkDlg = true }
                Tb(Icons.Filled.Schedule, "Insert date and time") { content = Markup.insert(content, SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())) }
                Tb(Icons.Filled.HorizontalRule, "Divider line") { content = Markup.insert(content, "\n---\n") }
                Tb(Icons.Filled.ContentPaste, "Paste") { clip.getText()?.text?.let { content = Markup.insert(content, it) } }
                Tb(Icons.Filled.Image, "Add image") { Session.external(); attachPicker.launch(arrayOf("image/*")) }
            }
        }
        Text("${wordCount(content.text)} words · ${content.text.length} characters", fontSize = 11.sp, color = onBg.copy(alpha = 0.55f),
            modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 16.dp, vertical = 6.dp))
    }

    // ---------------- dialogs & sheets ----------------
    if (linkDlg) {
        var label by remember { mutableStateOf(content.text.substring(content.selection.min, content.selection.max)) }
        var url by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { linkDlg = false }, title = { Text("Add link") },
            text = { Column { NeonField(label, { label = it }, "Text"); Spacer(Modifier.height(8.dp)); NeonField(url, { url = it }, "Address (https://…)") } },
            confirmButton = {
                TextButton(enabled = url.isNotBlank(), onClick = {
                    val sel = content.selection
                    val base = if (sel.min != sel.max) content.copy(text = content.text.removeRange(sel.min, sel.max), selection = androidx.compose.ui.text.TextRange(sel.min)) else content
                    content = Markup.insert(base, "[${label.ifBlank { url }}]($url)"); linkDlg = false
                }) { Text("Insert") }
            }, dismissButton = { TextButton(onClick = { linkDlg = false }) { Text("Cancel") } })
    }
    viewAtt?.let { a ->
        AttachViewer(vm, a, onExport = { exportAtt = a; Session.external(); attSaver.launch(a.name) }, onDelete = { vm.deleteAttachment(a); viewAtt = null }, onClose = { viewAtt = null })
    }
    confirmExport?.let { kind ->
        AlertDialog(onDismissRequest = { confirmExport = null }, title = { Text("Export private note?") },
            text = { Text("This creates an unencrypted copy outside the vault. Anyone with access to that file can read it.") },
            confirmButton = { TextButton(onClick = { confirmExport = null; doExport(kind) }) { Text("Export anyway", color = Axo.RgbPink) } },
            dismissButton = { TextButton(onClick = { confirmExport = null }) { Text("Cancel") } })
    }
    if (discard) AlertDialog(onDismissRequest = { discard = false }, title = { Text("Unsaved changes") },
        text = { Text("Autosave is off. Save before leaving?") },
        confirmButton = { TextButton(onClick = { discard = false; scope.launch { saveNow(); onBack() } }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { discard = false; onBack() }) { Text("Discard", color = Axo.RgbPink) } })
    if (vaultAuth) VaultAuthDialog(vm, { vaultAuth = false }, { vaultAuth = false; toggleVault() })

    if (sheet && entity != null) {
        val e = entity!!
        ModalBottomSheet(onDismissRequest = { sheet = false }) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
                SectionTitle("Colour")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NoteColors.forEachIndexed { i, c ->
                        Box(Modifier.size(34.dp).clip(CircleShape).background(if (i == 0) Color.Gray.copy(alpha = 0.4f) else c)
                            .then(if (e.color == i) Modifier.border(3.dp, Color.White, CircleShape) else Modifier).clickable { entity = e.copy(color = i) })
                    }
                }
                SectionTitle("Tags")
                NeonField(e.tags, { entity = e.copy(tags = it) }, "Comma separated, e.g. work, ideas")
                SectionTitle("Folder")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonChip("None", e.folderId == null, { entity = e.copy(folderId = null) })
                    folders.filter { it.isVault == e.encrypted }.forEach { f -> NeonChip(f.name, e.folderId == f.id, { entity = e.copy(folderId = f.id) }) }
                }
                SectionTitle("Reminder")
                val at = e.reminderAt
                if (at == null) {
                    NeonButton("Add reminder", {
                        ensureNotif()
                        pickDateTime(ctx, System.currentTimeMillis() + 3_600_000L) { t ->
                            if (t <= System.currentTimeMillis()) toast(ctx, "Pick a future time") else entity = e.copy(reminderAt = t, reminderDone = false)
                        }
                    }, icon = Icons.Filled.Alarm, filled = false)
                } else {
                    Text(fmtDate(at) + if (e.reminderDone) "  (completed)" else "")
                    Row {
                        TextButton(onClick = { pickDateTime(ctx, at) { t -> if (t <= System.currentTimeMillis()) toast(ctx, "Pick a future time") else entity = e.copy(reminderAt = t, reminderDone = false) } }) { Text("Edit") }
                        TextButton(onClick = { entity = e.copy(reminderDone = !e.reminderDone) }) { Text(if (e.reminderDone) "Mark active" else "Mark done") }
                        TextButton(onClick = { entity = e.copy(reminderAt = null, reminderDone = false) }) { Text("Delete", color = Axo.RgbPink) }
                    }
                }
                SectionTitle("Organise")
                SettingRow("Pinned") { Switch(checked = e.pinned, onCheckedChange = { entity = e.copy(pinned = it) }) }
                SettingRow("Favourite") { Switch(checked = e.favorite, onCheckedChange = { entity = e.copy(favorite = it) }) }
                SettingRow("Archived") { Switch(checked = e.archived, onCheckedChange = { entity = e.copy(archived = it) }) }
                Spacer(Modifier.height(8.dp))
                NeonButton(if (e.encrypted) "Move out of vault" else "Move to private vault", {
                    sheet = false
                    if (Session.vaultUnlocked) toggleVault() else vaultAuth = true
                }, Modifier.fillMaxWidth(), icon = if (e.encrypted) Icons.Filled.LockOpen else Icons.Filled.Lock, filled = false)
                SectionTitle("Actions")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Share", { sheet = false; requestExport("share") }, Modifier.weight(1f), filled = false)
                    NeonButton("TXT", { sheet = false; requestExport("txt") }, Modifier.weight(1f), filled = false)
                    NeonButton("PDF", { sheet = false; requestExport("pdf") }, Modifier.weight(1f), filled = false)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Duplicate", { scope.launch { saveNow(); entity?.takeIf { it.id > 0 }?.let { vm.duplicate(it); toast(ctx, "Duplicated") }; sheet = false } }, Modifier.weight(1f), filled = false)
                    NeonButton("Delete", {
                        scope.launch { saveNow(); entity?.takeIf { it.id > 0 }?.let { vm.trash(it) }; sheet = false; onBack() }
                    }, Modifier.weight(1f), filled = false)
                }
            }
        }
    }
}
