package com.axolie.axovault.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.axolie.axovault.data.MainVM
import com.axolie.axovault.security.Session
import com.axolie.axovault.ui.auth.LockScreen
import com.axolie.axovault.ui.auth.Onboarding
import com.axolie.axovault.ui.editor.EditorScreen
import com.axolie.axovault.ui.extras.*
import com.axolie.axovault.ui.main.FolderScreen
import com.axolie.axovault.ui.main.MainScreen
import com.axolie.axovault.ui.splash.SplashScreen

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val LOCK = "lock"
    const val MAIN = "main"
}

fun NavHostController.editor(id: Long, mode: String = "n") = navigate("editor/$id/$mode")

@Composable
fun AppNavHost() {
    val vm: MainVM = viewModel()
    val prefs = vm.prefs
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    LaunchedEffect(Session.locked, route) {
        if (Session.locked && prefs.configured && route != null && route != Routes.SPLASH && route != Routes.LOCK && route != Routes.ONBOARDING) {
            nav.navigate(Routes.LOCK) { popUpTo(nav.graph.id) { inclusive = true } }
        }
    }

    NavHost(
        navController = nav, startDestination = Routes.SPLASH,
        enterTransition = { fadeIn(tween(220)) + slideInHorizontally(tween(220)) { it / 12 } },
        exitTransition = { fadeOut(tween(150)) },
        popEnterTransition = { fadeIn(tween(220)) },
        popExitTransition = { fadeOut(tween(150)) + slideOutHorizontally(tween(150)) { it / 12 } }
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(onFinished = {
                val target = if (prefs.configured) Routes.LOCK else Routes.ONBOARDING
                nav.navigate(target) { popUpTo(Routes.SPLASH) { inclusive = true } }
            })
        }
        composable(Routes.ONBOARDING) {
            Onboarding(vm) { nav.navigate(Routes.MAIN) { popUpTo(nav.graph.id) { inclusive = true } } }
        }
        composable(Routes.LOCK) {
            LockScreen(vm) { nav.navigate(Routes.MAIN) { popUpTo(nav.graph.id) { inclusive = true } } }
        }
        composable(Routes.MAIN) { MainScreen(vm, nav) }
        composable(
            "editor/{id}/{mode}",
            arguments = listOf(navArgument("id") { type = NavType.LongType }, navArgument("mode") { type = NavType.StringType })
        ) { e ->
            EditorScreen(vm, e.arguments?.getLong("id") ?: -1L, e.arguments?.getString("mode") ?: "n") { nav.popBackStack() }
        }
        composable("folder/{fid}", arguments = listOf(navArgument("fid") { type = NavType.LongType })) { e ->
            FolderScreen(vm, nav, e.arguments?.getLong("fid") ?: -1L)
        }
        composable("trash") { TrashScreen(vm, nav) }
        composable("archive") { ArchiveScreen(vm, nav) }
        composable("calendar") { CalendarScreen(vm, nav) }
        composable("stats") { StatsScreen(vm, nav) }
        composable("reminders") { RemindersScreen(vm, nav) }
        composable("backup") { BackupScreen(vm, nav) }
        composable("theme") { ThemeScreen(vm, nav) }
    }
}
