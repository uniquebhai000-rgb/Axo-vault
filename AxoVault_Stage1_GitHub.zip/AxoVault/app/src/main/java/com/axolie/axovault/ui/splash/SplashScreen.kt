package com.axolie.axovault.ui.splash

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolie.axovault.R
import com.axolie.axovault.ui.theme.Axo
import com.axolie.axovault.ui.theme.rgbColorsAt
import com.axolie.axovault.ui.theme.rememberRgbPhase
import kotlin.random.Random

private class Particle(val x: Float, val y: Float, val speed: Float, val radius: Float, val colorIndex: Int, val alpha: Float)

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(2400, easing = FastOutSlowInEasing))
        kotlinx.coroutines.delay(250)
        onFinished()
    }

    val particles = remember {
        val r = Random(7)
        List(36) { Particle(r.nextFloat(), r.nextFloat(), 0.3f + r.nextFloat() * 0.7f, 1.5f + r.nextFloat() * 3f, r.nextInt(Axo.RgbPalette.size), 0.25f + r.nextFloat() * 0.5f) }
    }
    val t = rememberInfiniteTransition(label = "splash")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "drift")
    val pulse by t.animateFloat(0.97f, 1.03f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val phase = rememberRgbPhase(4000)

    Box(Modifier.fillMaxSize().background(Axo.Amoled), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            particles.forEach { p ->
                val y = ((p.y - drift * p.speed) % 1f + 1f) % 1f
                drawCircle(Axo.RgbPalette[p.colorIndex].copy(alpha = p.alpha), p.radius * density, Offset(p.x * size.width, y * size.height))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.axo_logo), "AXO VAULT", Modifier.size(230.dp).scale(pulse).clip(RoundedCornerShape(52.dp)))
            Spacer(Modifier.height(10.dp))
            Text("Your private digital vault", color = Axo.TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(36.dp))
            Box(Modifier.width(200.dp).height(4.dp).clip(CircleShape).background(Axo.Surface)) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(progress.value).clip(CircleShape)
                        .background(Brush.horizontalGradient(rgbColorsAt(phase)))
                )
            }
        }
    }
}
