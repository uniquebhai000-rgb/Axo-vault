package com.axolie.axovault.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** All cryptography lives here. No keys are hardcoded: the data key is random and wrapped by the Android Keystore. */
object Crypto {
    private const val KS = "AndroidKeyStore"
    private const val ALIAS = "axo_wrap_key"
    private const val MAGIC = "AXOB1"
    private lateinit var prefs: Prefs
    private var cached: SecretKey? = null
    private val rnd = SecureRandom()

    fun init(p: Prefs) { prefs = p }
    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)
    fun random(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }

    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance(KS).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KS)
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return kg.generateKey()
    }

    fun gcmEncrypt(key: SecretKey, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key)
        return c.iv + c.doFinal(data)
    }

    fun gcmDecrypt(key: SecretKey, blob: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob, 0, 12))
        return c.doFinal(blob, 12, blob.size - 12)
    }

    @Synchronized
    fun dataKey(): SecretKey {
        cached?.let { return it }
        if (prefs.wrappedKey.isEmpty()) prefs.wrappedKey = b64(gcmEncrypt(wrapKey(), random(32)))
        val raw = gcmDecrypt(wrapKey(), unb64(prefs.wrappedKey))
        return SecretKeySpec(raw, "AES").also { cached = it }
    }

    fun encryptBytes(d: ByteArray): ByteArray = gcmEncrypt(dataKey(), d)
    fun decryptBytes(d: ByteArray): ByteArray = gcmDecrypt(dataKey(), d)
    fun encryptText(s: String): String = b64(encryptBytes(s.toByteArray(Charsets.UTF_8)))
    fun decryptText(s: String): String = String(decryptBytes(unb64(s)), Charsets.UTF_8)

    private fun pbkdf2(secret: CharArray, salt: ByteArray, iter: Int): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(secret, salt, iter, 256)).encoded

    fun hash(secret: String): String {
        val salt = random(16)
        return b64(salt) + ":" + b64(pbkdf2(secret.toCharArray(), salt, 120_000))
    }

    fun verify(secret: String, stored: String): Boolean {
        if (stored.isEmpty()) return false
        val p = stored.split(":")
        if (p.size != 2) return false
        val h = pbkdf2(secret.toCharArray(), unb64(p[0]), 120_000)
        return MessageDigest.isEqual(h, unb64(p[1]))
    }

    fun encryptWithPassword(pw: String, data: ByteArray): ByteArray {
        val salt = random(16)
        val k = SecretKeySpec(pbkdf2(pw.toCharArray(), salt, 150_000), "AES")
        return MAGIC.toByteArray() + salt + gcmEncrypt(k, data)
    }

    fun decryptWithPassword(pw: String, blob: ByteArray): ByteArray {
        val m = MAGIC.toByteArray()
        require(blob.size > m.size + 16 + 28 && blob.copyOfRange(0, m.size).contentEquals(m)) { "Not an AXO VAULT backup" }
        val salt = blob.copyOfRange(m.size, m.size + 16)
        val body = blob.copyOfRange(m.size + 16, blob.size)
        val k = SecretKeySpec(pbkdf2(pw.toCharArray(), salt, 150_000), "AES")
        return gcmDecrypt(k, body)
    }
}
