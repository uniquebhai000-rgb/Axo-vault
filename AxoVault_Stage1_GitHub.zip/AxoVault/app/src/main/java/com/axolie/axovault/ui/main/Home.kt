package com.axolie.axovault.ui.main

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.axolie.axovault.data.*
import com.axolie.axovault.security.*
import com.axolie.axovault.ui.auth.*
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.theme.*
import com.axolie.axovault.util.*
import com.axolie.axovault.navigation.editor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import java.util.Calendar
import androidx.compose.ui.res.painterResource
import com.axolie.axovault.R

@Composable
fun MainScreen(vm: MainVM, nav: NavHostController) {
    val st = LocalStyle.current
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Box(Modifier.fillMaxWidth().height(260.dp).background(Brush.verticalGradient(listOf(st.accent.copy(alpha = 0.28f), Color.Transparent))))
        Column(Modifier.fillMaxSize()) {
            AxoTopBar(vm)
            Box(Modifier.weight(1f)) {
                Crossfade(vm.tab, label = "tab") { t ->
                    when (t) {
                        0 -> HomeTab(vm, nav)
                        1 -> NotesTab(vm, nav)
                        2 -> VaultTab(vm, nav)
                        3 -> FoldersTab(vm, nav)
                        else -> SettingsTab(vm, nav)
                    }
                }
            }
            BottomBar(vm.tab) { vm.tab = it }
        }
    }
}

@Composable
fun AxoTopBar(vm: MainVM) {
    val st = LocalStyle.current
    val titles = listOf("Home", "All Notes", "Private Vault", "Folders", "Settings")
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.axo_logo), "AXO VAULT", Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("AXO VAULT", style = androidx.compose.ui.text.TextStyle(brush = Brush.horizontalGradient(st.palette + st.palette.first()), fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp))
            Text(titles.getOrElse(vm.tab) { "" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        }
        IconButton(onClick = { vm.focusSearch = true; vm.tab = 1 }) { Icon(Icons.Filled.Search, "Search", tint = st.accent) }
        IconButton(onClick = { Session.lock() }) { Icon(Icons.Filled.Lock, "Lock now", tint = Axo.RgbPink) }
    }
}

@Composable
fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    val st = LocalStyle.current
    val phase = LocalPhase.current
    val haptic = LocalHapticFeedback.current
    val prefs = LocalPrefs.current
    val items = listOf(Icons.Filled.Home to "Home", Icons.Filled.Description to "Notes", Icons.Filled.Lock to "Vault", Icons.Filled.Folder to "Folders", Icons.Filled.Settings to "Settings")
    val on = MaterialTheme.colorScheme.onBackground
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
            .drawBehind { drawRect(Brush.horizontalGradient(rgbColorsAt(phase.value, st.palette)), size = Size(size.width, 2.dp.toPx())) }
            .navigationBarsPadding().padding(top = 4.dp, bottom = 4.dp)
    ) {
        items.forEachIndexed { i, (ic, l) ->
            Column(
                Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    if (prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onSel(i)
                }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(ic, l, tint = if (sel == i) st.accent else on.copy(alpha = 0.55f))
                Text(l, fontSize = 11.sp, color = if (sel == i) st.accent else on.copy(alpha = 0.55f))
                Box(Modifier.padding(top = 3.dp).size(width = 18.dp, height = 3.dp).clip(RoundedCornerShape(2.dp)).background(if (sel == i) st.accent else Color.Transparent))
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: Int, icon: ImageVector, color: Color, modifier: Modifier) {
    GlassCard(modifier) {
        Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(6.dp))
        Text("$value", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
    }
}

@Composable
fun HomeTab(vm: MainVM, nav: NavHostController) {
    val notes by vm.notes.collectAsState()
    val folders by vm.folders.collectAsState()
    var quick by remember { mutableStateOf(false) }
    var templates by remember { mutableStateOf(false) }
    var quickText by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val live = notes.filter { it.trashedAt == null }
    val normal = live.filter { !it.encrypted && !it.archived }
    val pinned = normal.filter { it.pinned }
    val recent = normal.sortedByDescending { it.modifiedAt }.take(5)
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when { hour < 5 -> "Good night"; hour < 12 -> "Good morning"; hour < 17 -> "Good afternoon"; else -> "Good evening" }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 24.dp)) {
        item {
            Text("AXO VAULT", fontSize = 12.sp, letterSpacing = 5.sp, color = Axo.Cyan, fontWeight = FontWeight.Bold)
            Text(greeting + if (vm.prefs.userName.isNotBlank()) ", ${vm.prefs.userName}" else "", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("${live.size} notes · ${live.count { it.encrypted }} private · all stored offline", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            Spacer(Modifier.height(14.dp))
            GlassCard(Modifier.fillMaxWidth(), onClick = { vm.focusSearch = true; vm.tab = 1 }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Search, null, tint = Axo.Cyan)
                    Spacer(Modifier.width(10.dp))
                    Text("Search your notes", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Total notes", live.size, Icons.Filled.Description, Axo.Cyan, Modifier.weight(1f))
                StatCard("Private", live.count { it.encrypted }, Icons.Filled.Lock, Axo.NeonPurple, Modifier.weight(1f))
                StatCard("Favourites", live.count { it.favorite && !it.encrypted }, Icons.Filled.Star, Axo.RgbPink, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton("New note", { nav.editor(-1) }, Modifier.weight(1f), icon = Icons.Filled.Add)
                NeonButton("Quick", { quick = true }, Modifier.weight(1f), icon = Icons.Filled.Bolt, filled = false)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton("Journal", { vm.openJournal { nav.editor(it) } }, Modifier.weight(1f), icon = Icons.Filled.Book, filled = false)
                NeonButton("Template", { templates = true }, Modifier.weight(1f), icon = Icons.Filled.Dashboard, filled = false)
            }
        }
        if (pinned.isNotEmpty()) {
            item { SectionTitle("Pinned") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(pinned, key = { it.id }) { n -> NoteCard(vm, n, { nav.editor(n.id) }, Modifier.width(240.dp)) }
                }
            }
        }
        item { SectionTitle("Recently edited") }
        if (recent.isEmpty()) item { EmptyState(Icons.Filled.Description, "No notes yet", "Create your first note to see it here.") }
        items(recent, key = { "r" + it.id }) { n -> NoteCard(vm, n, { nav.editor(n.id) }, Modifier.padding(bottom = 10.dp)) }
        val vf = folders.filter { !it.isVault }
        if (vf.isNotEmpty()) {
            item { SectionTitle("Folders") }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    vf.forEach { f -> NeonChip(f.name, false, { nav.navigate("folder/${f.id}") }, FolderIcons[f.icon]) }
                }
            }
        }
        item {
            SectionTitle("Explore")
            val ex = listOf(
                Triple("Calendar", Icons.Filled.CalendarMonth, "calendar"), Triple("Statistics", Icons.Filled.BarChart, "stats"),
                Triple("Reminders", Icons.Filled.Alarm, "reminders"), Triple("Archive", Icons.Filled.Archive, "archive"),
                Triple("Trash", Icons.Filled.Delete, "trash"), Triple("Customize", Icons.Filled.Palette, "theme")
            )
            ex.chunked(3).forEach { row ->
                Row(Modifier.padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (l, ic, r) ->
                        GlassCard(Modifier.weight(1f), onClick = { nav.navigate(r) }) {
                            Icon(ic, null, tint = Axo.Cyan)
                            Spacer(Modifier.height(4.dp))
                            Text(l, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
    if (quick) AlertDialog(
        onDismissRequest = { quick = false }, title = { Text("Quick note") },
        text = { NeonField(quickText, { quickText = it }, "Type and save", singleLine = false) },
        confirmButton = { TextButton(onClick = { vm.quickNote(quickText); quickText = ""; quick = false; toast(ctx, "Saved") }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { quick = false }) { Text("Cancel") } }
    )
    if (templates) AlertDialog(
        onDismissRequest = { templates = false }, title = { Text("Choose a template") },
        text = {
            Column {
                Templates.all.forEach { t ->
                    TextButton(onClick = { templates = false; nav.editor(-1, "t_" + t.key) }) { Text(t.name) }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton(onClick = { templates = false }) { Text("Close") } }
    )
}
