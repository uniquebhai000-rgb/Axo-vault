package com.axolie.axovault.ui.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import com.axolie.axovault.R
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolie.axovault.data.MainVM
import com.axolie.axovault.security.*
import com.axolie.axovault.ui.common.*
import com.axolie.axovault.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Password / PIN / biometric panel. Shared by the lock screen and the vault gate. */
@Composable
fun AuthPanel(vm: MainVM, onSuccess: () -> Unit, autoBiometric: Boolean = true) {
    val prefs = vm.prefs
    val auth = vm.auth
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var usePin by remember { mutableStateOf(prefs.pinHash.isNotEmpty()) }
    var pin by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var remain by remember { mutableLongStateOf(auth.remainingMs()) }
    LaunchedEffect(Unit) { while (true) { remain = auth.remainingMs(); delay(500) } }
    val bioOk = prefs.biometric && biometricAvailable(ctx)

    fun bio() {
        val a = ctx.findActivity() ?: return
        showBiometric(a, "Unlock AXO VAULT", { auth.ok(); onSuccess() }, { err = it })
    }
    LaunchedEffect(Unit) { if (autoBiometric && bioOk) bio() }

    fun verify(isPin: Boolean, secret: String) {
        if (busy) return
        busy = true
        scope.launch {
            val ok = withContext(Dispatchers.Default) { if (isPin) auth.checkPin(secret) else auth.checkPassword(secret) }
            busy = false
            if (ok) { auth.ok(); onSuccess() }
            else { auth.fail(); err = if (isPin) "Wrong PIN" else "Wrong password"; pin = ""; pw = "" }
        }
    }

    val locked = remain > 0
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonChip("PIN", usePin, { usePin = true; err = null })
            NeonChip("Password", !usePin, { usePin = false; err = null })
        }
        Spacer(Modifier.height(20.dp))
        if (locked) {
            Text("Too many attempts. Try again in ${remain / 1000 + 1}s", color = Axo.RgbPink, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
        } else if (err != null) {
            Text(err!!, color = Axo.RgbPink)
            Spacer(Modifier.height(12.dp))
        }
        if (usePin) {
            PinPad(value = pin, maxLen = prefs.pinLen, enabled = !locked && !busy, onChange = {
                pin = it
                if (it.length == prefs.pinLen) verify(true, it)
            }, extra = {
                if (bioOk) IconButton(onClick = { bio() }) { Icon(Icons.Filled.Fingerprint, "Biometric", tint = Axo.Cyan) }
            })
        } else {
            NeonField(pw, { pw = it }, "Master password", password = true, enabled = !locked)
            Spacer(Modifier.height(14.dp))
            NeonButton("Unlock", { verify(false, pw) }, Modifier.fillMaxWidth(), enabled = !locked && !busy && pw.isNotEmpty())
            if (bioOk) {
                Spacer(Modifier.height(10.dp))
                NeonButton("Use biometrics", { bio() }, Modifier.fillMaxWidth(), icon = Icons.Filled.Fingerprint, filled = false)
            }
        }
    }
}

@Composable
fun LockScreen(vm: MainVM, onUnlocked: () -> Unit) {
    var forgot by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Image(painterResource(R.drawable.axo_logo), "AXO VAULT", Modifier.size(130.dp).clip(RoundedCornerShape(30.dp)))
        Spacer(Modifier.height(14.dp))
        Text("AXO VAULT", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
        Text("Unlock to continue", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        Spacer(Modifier.height(28.dp))
        AuthPanel(vm, onSuccess = { Session.unlock(); onUnlocked() })
        Spacer(Modifier.height(18.dp))
        TextButton(onClick = { forgot = true }) { Text("Forgot password?", color = Axo.Cyan) }
    }
    if (forgot) RecoveryDialog(vm) { forgot = false }
}

@Composable
fun RecoveryDialog(vm: MainVM, onDismiss: () -> Unit) {
    val prefs = vm.prefs
    val scope = rememberCoroutineScope()
    var answer by remember { mutableStateOf("") }
    var verified by remember { mutableStateOf(false) }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Recover access") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (prefs.question.isEmpty()) {
                    Text("No recovery question was set up, so the password cannot be reset from inside the app. " +
                        "Your notes are encrypted with a key tied to this phone. If you also lost your PIN and fingerprint, the only way out is to clear the app's data, which permanently deletes all notes. Restore from a backup file afterwards.")
                } else if (!verified) {
                    Text(prefs.question)
                    Spacer(Modifier.height(8.dp))
                    NeonField(answer, { answer = it }, "Your answer")
                } else {
                    Text("Set a new password and PIN. Your notes are not affected.")
                    Spacer(Modifier.height(8.dp))
                    NeonField(pw, { pw = it }, "New master password (min 8)", password = true)
                    Spacer(Modifier.height(8.dp))
                    NeonField(pw2, { pw2 = it }, "Repeat password", password = true)
                    Spacer(Modifier.height(8.dp))
                    NeonField(pin, { pin = it.filter(Char::isDigit).take(8) }, "New PIN (4-8 digits)", password = true, keyboardType = KeyboardType.NumberPassword)
                }
                if (err != null) { Spacer(Modifier.height(8.dp)); Text(err!!, color = Axo.RgbPink) }
            }
        },
        confirmButton = {
            if (prefs.question.isNotEmpty()) TextButton(onClick = {
                if (!verified) {
                    scope.launch {
                        val ok = withContext(Dispatchers.Default) { vm.auth.checkAnswer(answer) }
                        if (ok) { verified = true; err = null } else { vm.auth.fail(); err = "Incorrect answer" }
                    }
                } else if (pw.length < 8 || pw != pw2) err = "Passwords must match and be 8+ characters"
                else if (pin.length < 4) err = "PIN must be 4-8 digits"
                else scope.launch {
                    val h = withContext(Dispatchers.Default) { Crypto.hash(pw) to Crypto.hash(pin) }
                    prefs.passHash = h.first; prefs.pinHash = h.second; prefs.pinLen = pin.length
                    vm.auth.ok()
                    onDismiss()
                }
            }) { Text(if (verified) "Save" else "Verify") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

/** Asks for PIN / password / biometrics before the vault opens. */
@Composable
fun VaultAuthDialog(vm: MainVM, onDismiss: () -> Unit, onSuccess: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Unlock private vault") },
        text = { AuthPanel(vm, onSuccess = { Session.unlockVault(); onSuccess() }) },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
