# AXO VAULT
Premium offline Android notes & private vault by AXOLIE.
Build: push to GitHub -> Actions tab -> "Build AXO VAULT APK" -> download artifact.
